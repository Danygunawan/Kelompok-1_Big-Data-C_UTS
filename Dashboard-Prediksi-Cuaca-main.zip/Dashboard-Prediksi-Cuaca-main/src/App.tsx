/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sidebar } from "./components/Sidebar";
import { Overview } from "./components/Overview";
import { PreprocessingView } from "./components/PreprocessingView";
import { RainfallView } from "./components/RainfallView";
import { RiceSuitabilityView } from "./components/RiceSuitabilityView";
import { HarvestAreaView } from "./components/HarvestAreaView";
import { VariabilityView } from "./components/VariabilityView";
import { CorrelationView } from "./components/CorrelationView";
import { BigData8VView } from "./components/BigData8VView";
import { ConclusionView } from "./components/ConclusionView";
import { PythonScriptView } from "./components/PythonScriptView";

import { generateRawBMKGData, generateRawBPSData } from "./data/datasets";
import { runBMKGPreprocessing } from "./utils/preprocessing";

import { Calendar, User, Sliders } from "lucide-react";

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>("overview");

  // Load Raw datasets once at load time
  const rawBMKG = useMemo(() => generateRawBMKGData(), []);
  const rawBPS = useMemo(() => generateRawBPSData(), []);

  // Run the full veracity processing pipeline
  const pipelineResult = useMemo(() => {
    return runBMKGPreprocessing(rawBMKG);
  }, [rawBMKG]);

  // Extract variables for simpler view passing
  const { cleanedDays, monthlyData, summary, rawStats, cleanStats } = pipelineResult;

  // Extract rainfall totals as flat array for lag correlation
  const monthlyRainfallTotals = useMemo(() => {
    return monthlyData.map((m) => m.total_curah_hujan);
  }, [monthlyData]);

  // Tab Header title mapper
  const tabTitles: Record<string, { title: string; subtitle: string }> = {
    overview: {
      title: "🎨 Overview Dashboard Utama",
      subtitle: "Sekilas KPI Makro, Agroklimatologi Regional Jabar 2025"
    },
    preprocessing: {
      title: "⚙️ Dataset & Pipeline Preprocessing (Veracity)",
      subtitle: "Bypass kelayakan data cuaca harian BMKG s.d bulanan BPS"
    },
    rainfall: {
      title: "🌧️ Karakteristik Curah Hujan Bulanan (BMKG)",
      subtitle: "Status intensitas curah hujan regional Stasiun Klimatologi Bogor"
    },
    suitability: {
      title: "✅ Indikator Kesesuaian Tanam Padi sawah",
      subtitle: "Rekomendasi taktis periode tanam padi berdasarkan curah air"
    },
    harvest: {
      title: "🌾 Dinamika Luas Panen Padi Sub-Regional (BPS)",
      subtitle: "Memonitor fluktuasi luas sawah dipanen per kabupaten/kota"
    },
    variability: {
      title: "📊 Peta Variabilitas Spasial-Temporal (Normalisasi)",
      subtitle: "Analisis kemandirian dan keselarasan musim tanam antar daerah"
    },
    correlation: {
      title: "🔗 Korelasi Pearson Berorientasi Lag Waktu (Validity)",
      subtitle: "Koefisien timbal balik cuaca hulu terhadap luas panen hilir"
    },
    bigdata8v: {
      title: "🧬 Penerapan Prinsip 8V Big Data",
      subtitle: "Verifikasi kepatuhan arsitektur solusi terhadap rubrik 8V"
    },
    conclusions: {
      title: "📈 Kesimpulan Strategis & Potensi Pengembangan",
      subtitle: "Intisari temuan & rekomendasi kebijakan musim tanam"
    },
    pythoncode: {
      title: "💻 Aset Script & Tutorial Python Streamlit",
      subtitle: "File app.py dan dependensi requirements.txt siap pakai lokal"
    }
  };

  return (
    <div id="app-main-layout" className="flex h-screen bg-[#fbf9f4] text-[#1a3c34] overflow-hidden font-sans">
      
      {/* Sidebar Navigation */}
      <Sidebar currentTab={currentTab} setTab={setCurrentTab} />

      {/* Right Core Content Frame */}
      <div id="content-core-frame" className="flex-1 flex flex-col h-full overflow-hidden">
        
        {/* Global Page Header */}
        <header id="tab-header" className="h-20 bg-white border-b border-[#e2e8e0] px-8 flex items-center justify-between shrink-0 select-none shadow-sm">
          <div>
            <h2 className="font-sans font-bold text-lg text-[#2d6a4f] tracking-tight leading-none">
              {tabTitles[currentTab]?.title || "Dashboard Analisis"}
            </h2>
            <p className="text-xs text-[#6b7c76] mt-1.5 font-normal leading-none">
              {tabTitles[currentTab]?.subtitle || "Sistem Agroklimatologi Jawa Barat 2025"}
            </p>
          </div>

          <div className="flex items-center gap-5 text-xs font-semibold">
            <div className="flex items-center gap-2 bg-[#f0f7f4] border border-[#d8eadd] px-3 py-1.5 rounded-xl text-[#1b4332]">
              <Calendar className="w-4 h-4 text-[#2d6a4f]" />
              <span>Hari ini: <strong className="text-[#102a1e]">16 Juni 2331 UTC</strong></span>
            </div>
            
            <div className="flex items-center gap-2 bg-[#fff8f0] border border-[#fbe9d0] px-3 py-1.5 rounded-xl text-[#c2843e]">
              <User className="w-4 h-4 text-[#c2843e]" />
              <span>Data Analyst: <strong className="text-[#684318]">danz</strong></span>
            </div>
          </div>
        </header>

        {/* Scrollable View Containment Area */}
        <main id="app-viewport" className="flex-1 overflow-y-auto p-8 bg-[#fbf9f4] scrollbar-thin scrollbar-thumb-slate-200">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18, ease: "easeInOut" }}
              className="h-full"
            >
              {currentTab === "overview" && (
                <Overview 
                  cleanedDays={cleanedDays}
                  monthlyRainfall={monthlyData}
                  harvestData={rawBPS}
                />
              )}

              {currentTab === "preprocessing" && (
                <PreprocessingView 
                  rawBMKG={rawBMKG}
                  cleanedDays={cleanedDays}
                  rawBPS={rawBPS}
                  summary={summary}
                  rawStats={rawStats}
                  cleanStats={cleanStats}
                />
              )}

              {currentTab === "rainfall" && (
                <RainfallView monthlyRainfall={monthlyData} />
              )}

              {currentTab === "suitability" && (
                <RiceSuitabilityView monthlyRainfall={monthlyData} />
              )}

              {currentTab === "harvest" && (
                <HarvestAreaView harvestData={rawBPS} />
              )}

              {currentTab === "variability" && (
                <VariabilityView harvestData={rawBPS} />
              )}

              {currentTab === "correlation" && (
                <CorrelationView 
                  monthlyRainfall={monthlyRainfallTotals}
                  harvestData={rawBPS}
                />
              )}

              {currentTab === "bigdata8v" && (
                <BigData8VView />
              )}

              {currentTab === "conclusions" && (
                <ConclusionView />
              )}

              {currentTab === "pythoncode" && (
                <PythonScriptView />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

      </div>
    </div>
  );
}
