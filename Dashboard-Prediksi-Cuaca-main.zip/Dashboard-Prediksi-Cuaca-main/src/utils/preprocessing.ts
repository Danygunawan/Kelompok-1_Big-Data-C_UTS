/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MONTHS, REGENCY_LIST } from "../data/datasets";

export interface CleanedBMKGDay {
  tanggal: string; // Uniform YYYY-MM-DD
  suhu_min: number;
  suhu_max: number;
  suhu_avg: number;
  kelembapan_avg: number;
  curah_hujan: number; // Cleansed milimeters
  penyinaran_matahari: number;
  bulan_idx: number; // 0-11
}

export interface MonthlyBMKG {
  bulan_idx: number;
  bulan_nama: string;
  total_curah_hujan: number; // Total / sum
  avg_suhu_min: number;
  avg_suhu_max: number;
  avg_suhu_avg: number;
  avg_kelembapan: number;
  avg_penyinaran: number;
}

export interface PreprocessingSummary {
  raw_count: number;
  clean_count: number;
  duplicates_removed: number;
  invalid_values_treated: number; // count of 8888, 9999, negative outliers etc.
  nulls_imputed: number;
}

// Custom Date Parser that can handle YYYY-MM-DD, YYYY/MM/DD, DD-MM-YYYY
export function parseFlexibleDate(dateStr: string): Date | null {
  if (!dateStr) return null;
  
  // Try YYYY-MM-DD or YYYY/MM/DD
  if (dateStr.includes("/")) {
    const parts = dateStr.split("/");
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      return new Date(year, month, day);
    }
  }
  
  if (dateStr.includes("-")) {
    const parts = dateStr.split("-");
    if (parts.length === 3) {
      // Check if DD-MM-YYYY (first part has length 1 or 2)
      if (parts[0].length <= 2) {
        const day = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        const year = parseInt(parts[2], 10);
        return new Date(year, month, day);
      } else {
        // YYYY-MM-DD
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        const day = parseInt(parts[2], 10);
        return new Date(year, month, day);
      }
    }
  }

  const d = new Date(dateStr);
  return isNaN(d.getTime()) ? null : d;
}

// Full cleaning pipeline
export function runBMKGPreprocessing(rawDays: any[]): {
  cleanedDays: CleanedBMKGDay[];
  monthlyData: MonthlyBMKG[];
  summary: PreprocessingSummary;
  rawStats: Record<string, number>;
  cleanStats: Record<string, number>;
} {
  const summary: PreprocessingSummary = {
    raw_count: rawDays.length,
    clean_count: 0,
    duplicates_removed: 0,
    invalid_values_treated: 0,
    nulls_imputed: 0
  };

  // 1. Parser and Deduplicator
  const uniqueRecords: Record<string, any> = {};
  
  rawDays.forEach((day) => {
    const parsedDate = parseFlexibleDate(day.tanggal);
    if (!parsedDate) return; // Ignore unparseable
    
    // Check for 2025 boundary
    if (parsedDate.getFullYear() !== 2025) return;

    const standardizedDate = parsedDate.toISOString().split("T")[0];
    
    // If already exists, mark duplicate
    if (uniqueRecords[standardizedDate]) {
      summary.duplicates_removed++;
      return;
    }
    
    uniqueRecords[standardizedDate] = { 
      ...day, 
      parsedDate,
      tanggal: standardizedDate,
      bulan_idx: parsedDate.getMonth() 
    };
  });

  // Sort by date
  const sortedDays = Object.values(uniqueRecords).sort((a, b) => {
    return a.parsedDate.getTime() - b.parsedDate.getTime();
  });

  // 2. Identify missing values and Replace 8888/9999 with NaN
  const treatedDays = sortedDays.map((day) => {
    const fresh = { ...day };
    
    const checkAndReplace = (val: any, fieldName: string) => {
      if (val === 8888 || val === 9999 || val === "8888" || val === "9999") {
        summary.invalid_values_treated++;
        return null;
      }
      if (val === null || val === undefined || isNaN(Number(val))) {
        return null;
      }
      const num = Number(val);
      // Extra validation check: e.g. Rainfall cannot be negative, temperature shouldn't be negative in Jabar, etc.
      if (fieldName === "curah_hujan" && num < 0) {
        summary.invalid_values_treated++;
        return null;
      }
      if (fieldName === "kelembapan_avg" && (num < 0 || num > 100)) {
        summary.invalid_values_treated++;
        return null;
      }
      return num;
    };

    fresh.suhu_min = checkAndReplace(fresh.suhu_min, "suhu_min");
    fresh.suhu_max = checkAndReplace(fresh.suhu_max, "suhu_max");
    fresh.suhu_avg = checkAndReplace(fresh.suhu_avg, "suhu_avg");
    fresh.kelembapan_avg = checkAndReplace(fresh.kelembapan_avg, "kelembapan_avg");
    fresh.curah_hujan = checkAndReplace(fresh.curah_hujan, "curah_hujan");
    fresh.penyinaran_matahari = checkAndReplace(fresh.penyinaran_matahari, "penyinaran_matahari");
    
    return fresh;
  });

  // 3. Impute missing values via linear interpolation (for series continuity)
  // If the first or last is null, we can fallback to the yearly median/mean.
  const fields = ["suhu_min", "suhu_max", "suhu_avg", "kelembapan_avg", "curah_hujan", "penyinaran_matahari"];
  const fallbacks: Record<string, number> = {
    suhu_min: 22.1,
    suhu_max: 31.8,
    suhu_avg: 25.5,
    kelembapan_avg: 84.0,
    curah_hujan: 5.2, // average typical rainfall day
    penyinaran_matahari: 4.8
  };

  const finalCleaned: CleanedBMKGDay[] = treatedDays.map((_, idx) => {
    const item = treatedDays[idx];
    const imputedItem: any = {
      tanggal: item.tanggal,
      bulan_idx: item.bulan_idx
    };

    fields.forEach((field) => {
      let val = item[field];
      if (val === null) {
        summary.nulls_imputed++;
        
        // Find previous non-null value
        let prevVal: number | null = null;
        for (let i = idx - 1; i >= 0; i--) {
          if (treatedDays[i][field] !== null) {
            prevVal = treatedDays[i][field];
            break;
          }
        }

        // Find next non-null value
        let nextVal: number | null = null;
        for (let i = idx + 1; i < treatedDays.length; i++) {
          if (treatedDays[i][field] !== null) {
            nextVal = treatedDays[i][field];
            break;
          }
        }

        // Perform interpolation
        if (prevVal !== null && nextVal !== null) {
          val = Math.round(((prevVal + nextVal) / 2) * 10) / 10;
        } else if (prevVal !== null) {
          val = prevVal;
        } else if (nextVal !== null) {
          val = nextVal;
        } else {
          val = fallbacks[field];
        }
      }
      imputedItem[field] = val;
    });

    return imputedItem as CleanedBMKGDay;
  });

  summary.clean_count = finalCleaned.length;

  // 4. Aggregate to monthly
  const monthlyData: MonthlyBMKG[] = Array.from({ length: 12 }, (_, b_idx) => {
    const b_days = finalCleaned.filter((d) => d.bulan_idx === b_idx);
    
    // Rainfall total / sum
    const total_curah_hujan = Math.round(b_days.reduce((acc, d) => acc + d.curah_hujan, 0) * 10) / 10;
    
    // Averages
    const avg_suhu_min = Math.round((b_days.reduce((acc, d) => acc + d.suhu_min, 0) / Math.max(1, b_days.length)) * 10) / 10;
    const avg_suhu_max = Math.round((b_days.reduce((acc, d) => acc + d.suhu_max, 0) / Math.max(1, b_days.length)) * 10) / 10;
    const avg_suhu_avg = Math.round((b_days.reduce((acc, d) => acc + d.suhu_avg, 0) / Math.max(1, b_days.length)) * 10) / 10;
    const avg_kelembapan = Math.round((b_days.reduce((acc, d) => acc + d.kelembapan_avg, 0) / Math.max(1, b_days.length)) * 10) / 10;
    const avg_penyinaran = Math.round((b_days.reduce((acc, d) => acc + d.penyinaran_matahari, 0) / Math.max(1, b_days.length)) * 10) / 10;

    return {
      bulan_idx: b_idx,
      bulan_nama: MONTHS[b_idx],
      total_curah_hujan,
      avg_suhu_min,
      avg_suhu_max,
      avg_suhu_avg,
      avg_kelembapan,
      avg_penyinaran
    };
  });

  // Calculate some simple statistical counts before vs after
  // Let's count nulls/invalid directly on raw dataset
  let rawNullCount = 0;
  rawDays.forEach((d) => {
    fields.forEach((f) => {
      const val = d[f];
      if (val === null || val === undefined || val === 8888 || val === 9999 || val === "8888" || val === "9999") {
        rawNullCount++;
      }
    });
  });

  const rawStats = {
    total_records: rawDays.length,
    total_nulls_or_dirty: rawNullCount,
    avg_rainfall: Math.round((rawDays.reduce((acc, d) => {
      const num = Number(d.curah_hujan);
      return acc + (isNaN(num) || num > 1000 ? 0 : num);
    }, 0) / rawDays.length) * 10) / 10
  };

  const cleanStats = {
    total_records: finalCleaned.length,
    total_nulls_or_dirty: 0,
    avg_rainfall: Math.round((finalCleaned.reduce((acc, d) => acc + d.curah_hujan, 0) / finalCleaned.length) * 10) / 10
  };

  return {
    cleanedDays: finalCleaned,
    monthlyData,
    summary,
    rawStats,
    cleanStats
  };
}

// Calculate Pearson Correlation Coefficient between rainfall (with month lag) and harvest area of regencies
// Lag specifies how many months are shifted backwards for curah_hujan.
// E.g. Lag 2 means: Curah Hujan in month t-2 is correlated with Luas Panen in month t.
export function calculateLagCorrelation(
  monthlyRainfall: number[], // 12 elements (Jan-Dec)
  monthlyHarvest: number[],  // 12 elements (Jan-Dec)
  lag: number // 0, 1, 2, 3
): number {
  const n = 12 - lag; // Valid matching instances
  if (n <= 2) return 0;
  
  let rainSlice: number[] = [];
  let harvestSlice: number[] = [];
  
  for (let i = lag; i < 12; i++) {
    rainSlice.push(monthlyRainfall[i - lag]);
    harvestSlice.push(monthlyHarvest[i]);
  }

  // Calculate Pearson correlation
  const meanRain = rainSlice.reduce((a, b) => a + b, 0) / n;
  const meanHarvest = harvestSlice.reduce((a, b) => a + b, 0) / n;
  
  let num = 0;
  let denRain = 0;
  let denHarvest = 0;
  
  for (let idx = 0; idx < n; idx++) {
    const diffRain = rainSlice[idx] - meanRain;
    const diffHarvest = harvestSlice[idx] - meanHarvest;
    
    num += diffRain * diffHarvest;
    denRain += diffRain * diffRain;
    denHarvest += diffHarvest * diffHarvest;
  }
  
  if (denRain === 0 || denHarvest === 0) return 0;
  
  const r = num / Math.sqrt(denRain * denHarvest);
  return Math.round(r * 100) / 100; // 2 decimal places
}

// Generate the matrix of correlations for all regencies with lag 0 to 3
export interface RegencyCorr {
  regency: string;
  lag0: number;
  lag1: number;
  lag2: number;
  lag3: number;
  max_lag: number; // which lag has the absolute largest correlation
  max_val: number;
}

export function generateAllCorrelations(
  monthlyRainfall: number[], // 12 elements from BMKG Bogor
  harvestData: Record<string, number[]> // Regency -> 12 values
): RegencyCorr[] {
  return REGENCY_LIST.map((regency) => {
    const harvestValues = harvestData[regency] || Array(12).fill(0);
    const r0 = calculateLagCorrelation(monthlyRainfall, harvestValues, 0);
    const r1 = calculateLagCorrelation(monthlyRainfall, harvestValues, 1);
    const r2 = calculateLagCorrelation(monthlyRainfall, harvestValues, 2);
    const r3 = calculateLagCorrelation(monthlyRainfall, harvestValues, 3);
    
    const absArray = [Math.abs(r0), Math.abs(r1), Math.abs(r2), Math.abs(r3)];
    const maxIdx = absArray.indexOf(Math.max(...absArray));
    const vals = [r0, r1, r2, r3];

    return {
      regency,
      lag0: r0,
      lag1: r1,
      lag2: r2,
      lag3: r3,
      max_lag: maxIdx,
      max_val: vals[maxIdx]
    };
  });
}
