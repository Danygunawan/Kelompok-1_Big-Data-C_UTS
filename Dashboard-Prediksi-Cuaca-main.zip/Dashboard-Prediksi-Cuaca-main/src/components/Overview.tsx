/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React from "react";
import { 
  CloudRain, 
  Sprout, 
  Calendar, 
  Map, 
  Droplets,
  Award,
  Sun,
  AlertCircle
} from "lucide-react";
import { MONTHS } from "../data/datasets";
import { CleanedBMKGDay, MonthlyBMKG } from "../utils/preprocessing";

interface OverviewProps {
  cleanedDays: CleanedBMKGDay[];
  monthlyRainfall: MonthlyBMKG[];
  harvestData: Record<string, number[]>;
}

export const Overview: React.FC<OverviewProps> = ({ 
  cleanedDays, 
  monthlyRainfall, 
  harvestData 
}) => {
  // Aggregate statistics
  const totalDays = cleanedDays.length;
  const totalMonths = 12;
  const regenciesCount = Object.keys(harvestData).length;

  // Total Harvest Area in Ha
  let totalHarvestArea = 0;
  (Object.values(harvestData) as number[][]).forEach((row) => {
    row.forEach((v) => { totalHarvestArea += v; });
  });

  // Total Rainfall
  const totalRainfall = monthlyRainfall.reduce((acc, m) => acc + m.total_curah_hujan, 0);

  // Highest and lowest rainfall months
  let highestRainMonth = monthlyRainfall[0];
  let lowestRainMonth = monthlyRainfall[0];
  monthlyRainfall.forEach((m) => {
    if (m.total_curah_hujan > highestRainMonth.total_curah_hujan) highestRainMonth = m;
    if (m.total_curah_hujan < lowestRainMonth.total_curah_hujan) lowestRainMonth = m;
  });

  // Top Regency / Kabupaten with maximum total harvest area
  let topRegency = "";
  let topRegencyVal = -1;
  (Object.entries(harvestData) as [string, number[]][]).forEach(([regency, values]) => {
    const total = values.reduce((a, b) => a + b, 0);
    if (total > topRegencyVal) {
      topRegencyVal = total;
      topRegency = regency;
    }
  });

  return (
    <div id="overview-view" className="space-y-6">
      {/* Intro Header Card */}
      <div id="overview-hero-card" className="bg-gradient-to-r from-[#1a4d4d] to-[#2d6a4f] text-white rounded-3xl p-8 border border-[#256060] shadow-md relative overflow-hidden">
        <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 opacity-10">
          <Sprout className="w-80 h-80 text-white" />
        </div>
        <div className="relative z-10 max-w-3xl">
          <span className="bg-white/10 border border-white/20 text-[#a8dadc] font-mono text-xs uppercase px-3 py-1 rounded-full font-semibold tracking-wider">
            Sistem Informasi Agroklimatologi Jawa Barat
          </span>
          <h2 className="font-sans font-bold text-3xl md:text-3xl text-white mt-4 tracking-tight leading-tight">
            Analisis Curah Hujan & Luas Panen Padi Jabar 2025
          </h2>
          <p className="text-[#e8f3f1]/90 text-sm mt-3 leading-relaxed">
            Dashboard ini menganalisis curah hujan dari Stasiun Klimatologi Jawa Barat di Bogor dan luas panen padi seluruh kabupaten/kota Jawa Barat selama Januari–Desember 2025. Dilengkapi data visualisasi interaktif untuk memeriksa interaksi iklim-pertanian, optimalisasi masa tanam, dan analisis variabilitas wilayah.
          </p>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div id="kpi-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total BMKG Observation Days */}
        <div className="bg-white rounded-2xl p-5 border border-[#e2e8e0] shadow-sm hover:translate-y-[-2px] transition duration-200">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold tracking-wider text-[#6b7c76] uppercase">Observasi BMKG</span>
            <div className="bg-[#e7f5ef] p-2 rounded-xl text-[#2d6a4f]"><Calendar className="w-5 h-5" /></div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-sans font-bold text-[#1a3c34] tracking-tight">{totalDays}</span>
            <span className="text-[#6b7c76] text-xs ml-1">Hari</span>
          </div>
          <p className="text-[#6b7c76] text-[11px] mt-1.5 leading-none font-normal">Cakupan harian Stasiun Klimatologi Bogor</p>
        </div>

        {/* Total Harvested Area */}
        <div className="bg-white rounded-2xl p-5 border border-[#e2e8e0] shadow-sm hover:translate-y-[-2px] transition duration-200">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold tracking-wider text-[#6b7c76] uppercase">Total Luas Panen</span>
            <div className="bg-[#f0f4ff] p-2 rounded-xl text-[#4361ee]"><Sprout className="w-5 h-5" /></div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-sans font-bold text-[#1a3c34] tracking-tight">
              {totalHarvestArea.toLocaleString("id-ID")}
            </span>
            <span className="text-[#6b7c76] text-xs ml-1">Ha</span>
          </div>
          <p className="text-[#6b7c76] text-[11px] mt-1.5 leading-none font-normal">Total sawah dipanen (BPS Jawa Barat)</p>
        </div>

        {/* Annual Rainfall */}
        <div className="bg-white rounded-2xl p-5 border border-[#e2e8e0] shadow-sm hover:translate-y-[-2px] transition duration-200">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold tracking-wider text-[#6b7c76] uppercase">Total Curah Hujan</span>
            <div className="bg-[#e7f5ef] p-2 rounded-xl text-[#2d6a4f]"><CloudRain className="w-5 h-5" /></div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-sans font-bold text-[#1a3c34] tracking-tight">
              {totalRainfall.toLocaleString("id-ID")}
            </span>
            <span className="text-[#6b7c76] text-xs ml-1">mm</span>
          </div>
          <p className="text-[#6b7c76] text-[11px] mt-1.5 leading-none font-normal">Kategori: Cuaca Sangat Basah (Bogor)</p>
        </div>

        {/* Regency & Cities */}
        <div className="bg-white rounded-2xl p-5 border border-[#e2e8e0] shadow-sm hover:translate-y-[-2px] transition duration-200">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold tracking-wider text-[#6b7c76] uppercase">Cakupan Wilayah</span>
            <div className="bg-[#fff5f5] p-2 rounded-xl text-[#e5383b]"><Map className="w-5 h-5" /></div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-sans font-bold text-[#1a3c34] tracking-tight">{regenciesCount}</span>
            <span className="text-[#6b7c76] text-xs ml-1">Kab / Kota</span>
          </div>
          <p className="text-[#6b7c76] text-[11px] mt-1.5 leading-none font-normal">Pemerintahan Provinsi Jawa Barat</p>
        </div>
      </div>

      {/* Secondary KPI Grid for Extreme Insights */}
      <div id="secondary-kpi-grid" className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Top Rain Month */}
        <div className="bg-white border border-[#e2e8e0] rounded-2xl p-5 flex items-center gap-4 shadow-sm">
          <div className="p-3 bg-[#e7f5ef] text-[#2d6a4f] rounded-xl font-bold">
            <Droplets className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-mono font-bold text-[#6b7c76] uppercase tracking-wider">Hujan Terbanyak</p>
            <h4 className="font-sans font-bold text-[#1a3c34] text-base mt-0.5">{highestRainMonth.bulan_nama}</h4>
            <p className="text-xs text-[#6b7c76]">{highestRainMonth.total_curah_hujan.toLocaleString("id-ID")} mm</p>
          </div>
        </div>

        {/* Lowest Rain Month */}
        <div className="bg-white border border-[#e2e8e0] rounded-2xl p-5 flex items-center gap-4 shadow-sm">
          <div className="p-3 bg-[#fff8f0] text-[#c2843e] rounded-xl font-bold">
            <Sun className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-mono font-bold text-[#6b7c76] uppercase tracking-wider">Hujan Terkecil</p>
            <h4 className="font-sans font-bold text-[#1a3c34] text-base mt-0.5">{lowestRainMonth.bulan_nama}</h4>
            <p className="text-xs text-[#6b7c76]">{lowestRainMonth.total_curah_hujan.toLocaleString("id-ID")} mm</p>
          </div>
        </div>

        {/* Top rice producing basket */}
        <div className="bg-white border border-[#e2e8e0] rounded-2xl p-5 flex items-center gap-4 shadow-sm">
          <div className="p-3 bg-[#e7f5ef] text-[#2d6a4f] rounded-xl font-bold">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-mono font-bold text-[#6b7c76] uppercase tracking-wider">Lumbung Padi Terbesar</p>
            <h4 className="font-sans font-bold text-[#1a3c34] text-base mt-0.5">{topRegency}</h4>
            <p className="text-xs text-[#6b7c76] font-medium">Total: {topRegencyVal.toLocaleString("id-ID")} Ha</p>
          </div>
        </div>
      </div>      {/* Descriptive Metadata Explanation box */}
      <div id="regional-climate-warning" className="bg-[#fff8f0] border border-[#fbe9d0] rounded-2xl p-5 flex gap-4 items-start shadow-xs">
        <AlertCircle id="warning-icon" className="w-5 h-5 text-[#c2843e] shrink-0 mt-0.5" />
        <div>
          <h5 id="warning-title" className="font-sans font-semibold text-[#c2843e] text-sm">Catatan Validitas Representasi Klimatologi</h5>
          <p id="warning-content" className="text-xs text-[#6b7c76] mt-1 leading-relaxed">
            Data iklim dan curah hujan diproses dari pencatatan harian <strong>Stasiun Klimatologi Jawa Barat di Bogor</strong>. Oleh karena itu, data ini digunakan sebagai indikator iklim regional makro untuk Jawa Barat, bukan representasi mikroklimat presisi untuk setiap kabupaten/kota. Analisis spasial harus menafsirkan temuan ini dalam lingkup keterlibatan korelasi regional (Bogor sebagai basis rujukan proxy cuaca).
          </p>
        </div>
      </div>

      {/* Agricultural Context Panel */}
      <div className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm">
        <h3 className="font-sans font-bold text-[#1a3c34] text-lg">Konsep Hubungan Iklim & Hasil Tani</h3>
        <p className="text-xs text-[#6b7c76] mt-1">Mengapa curah hujan dikaitkan dengan pola luas panen?</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
          <div className="space-y-2 border-l-2 border-[#2d6a4f] pl-4">
            <h4 className="font-sans font-medium text-[#1a3c34] text-sm">1. Pola Tanam Padi Sawah</h4>
            <p className="text-xs text-[#6b7c76] leading-relaxed font-normal">
              Padi sawah sangat berorientasi pada ketersediaan air. Curah hujan bulanan optimal berkisar antara 100 s.d 200 mm per bulan, mendukung fase awal pelumpuran tanah dan pertumbuhan vegetatif tanaman.
            </p>
          </div>
          <div className="space-y-2 border-l-2 border-[#1b4332] pl-4">
            <h4 className="font-sans font-medium text-[#1a3c34] text-sm">2. Efek Time-Lag (Tunda Waktu)</h4>
            <p className="text-xs text-[#6b7c76] leading-relaxed font-normal">
              Masa tumbuh padi dari penanaman hingga panen memakan waktu sekitar 3 s.d 4 bulan. Intensitas hujan tinggi di bulan Januari (t-3) akan mempengaruhi kebasahan tanah dan debit air irigasi, yang korelasinya baru terlihat pada puncak luas panen di bulan April (t).
            </p>
          </div>
          <div className="space-y-2 border-l-2 border-[#c2843e] pl-4">
            <h4 className="font-sans font-medium text-[#1a3c34] text-sm">3. Risiko Iklim Ekstrem</h4>
            <p className="text-xs text-[#6b7c76] leading-relaxed font-normal">
              Curah hujan &lt; 50 mm (Kritis) akan meningkatkan ancaman kekeringan / fuso, sedangkan &gt; 200 mm (Berlebih) dapat memicu banjir di dataran rendah pesisir (seperti daerah pantura Karawang / Indramayu), yang mengganggu produktivitas.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
