/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from "react";
import { Sliders, HelpCircle, Activity } from "lucide-react";
import { MONTHS } from "../data/datasets";

interface VariabilityViewProps {
  harvestData: Record<string, number[]>;
}

export const VariabilityView: React.FC<VariabilityViewProps> = ({ harvestData }) => {
  
  // Format the normalized grid rows: Regency -> [12 normalized values]
  const normalizedGrid = useMemo(() => {
    return (Object.entries(harvestData) as [string, number[]][]).sort(([a], [b]) => a.localeCompare(b)).map(([regency, values]) => {
      const min = Math.min(...values);
      const max = Math.max(...values);
      const range = max - min;
      
      const normalizedValues = values.map((val) => {
        if (range === 0) return 0;
        return Math.round(((val - min) / range) * 100) / 100; // 0 to 1 rounded
      });

      return {
        regency,
        rawValues: values,
        normValues: normalizedValues,
        total: values.reduce((a, b) => a + b, 0)
      };
    });
  }, [harvestData]);

  // Color mapper from normalized value (0.0 - 1.0) to heat color classes:
  // Red (low) -> Yellow (mid) -> Emerald Green (high)
  const getHeatValueColor = (val: number) => {
    if (val < 0.15) return { bg: "bg-red-500 text-white", hex: "#ef4444" };
    if (val < 0.35) return { bg: "bg-orange-400 text-slate-900", hex: "#fb923c" };
    if (val < 0.55) return { bg: "bg-amber-300 text-slate-900", hex: "#fcd34d" };
    if (val < 0.75) return { bg: "bg-lime-400 text-slate-900", hex: "#a3e635" };
    if (val < 0.90) return { bg: "bg-emerald-500 text-white", hex: "#10b981" };
    return { bg: "bg-emerald-700 text-white font-bold", hex: "#047857" };
  };

  return (
    <div id="variability-view" className="space-y-6">

      {/* Main explanation header */}
      <div id="variability-banner" className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-[#f0f7f4] text-[#2d6a4f] rounded-2xl shrink-0">
            <Sliders className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-sans font-bold text-[#1a3c34] text-base">Analisis Variabilitas Spasial-Temporal Luas Panen</h3>
            <p className="text-xs text-[#6b7c76] mt-1 leading-relaxed">
              “Heatmap ini menunjukkan variasi relatif luas panen antar bulan dan antar wilayah. Warna hijau menunjukkan nilai relatif tinggi, sedangkan warna merah menunjukkan nilai relatif rendah.”
            </p>
            <p className="text-xs text-[#1a3c34] font-semibold mt-2.5 bg-[#f0f7f4]/50 p-2 border border-[#e2e8e0] rounded-xl leading-relaxed">
              <strong>Mengapa dinormalisasi?</strong> Untuk meredam bias absolut. Misalnya, luas sawah di Kota Sukabumi sangat kecil dibandingkan Kab. Indramayu. Jika menggunakan angka mentah, Kota Sukabumi akan terlihat merah selamanya di peta. Melalui normalisasi 0 s.d 1 per baris, kita bisa melihat pola <em>timing</em> panen raya murni daerah masing-masing secara setara.
            </p>
          </div>
        </div>
      </div>

      {/* Grid Heatmap Visual Board */}
      <div id="variability-grid-card" className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm overflow-hidden">
        
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-6">
          <div>
            <h4 className="font-sans font-bold text-[#1a3c34] text-sm">Matriks Normalisasi Luas Panen (0.0 - 1.0)</h4>
            <p className="text-[11px] text-[#6b7c76] mt-0.5">Sumbu X: Bulan Teramati (Jan-Des) | Sumbu Y: Kabupaten/Kota</p>
          </div>

          {/* Color Key Guide */}
          <div className="flex items-center gap-1.5 text-[10px] text-[#6b7c76] font-mono select-none">
            <span>Rendah (0.0)</span>
            <span className="w-3 h-3 rounded bg-red-500"></span>
            <span className="w-3 h-3 rounded bg-orange-400"></span>
            <span className="w-3 h-3 rounded bg-amber-300"></span>
            <span className="w-3 h-3 rounded bg-lime-400"></span>
            <span className="w-3 h-3 rounded bg-emerald-500"></span>
            <span className="w-3 h-3 rounded bg-emerald-700"></span>
            <span>Tinggi (1.0)</span>
          </div>
        </div>

        {/* Heatmap Grid Wrapper */}
        <div className="overflow-x-auto">
          <div className="min-w-[850px] space-y-1.5">
            
            {/* Header XAxis */}
            <div className="flex items-center text-center font-sans font-semibold text-slate-500 text-[10px] uppercase border-b border-slate-200 pb-2">
              <div className="w-48 text-left text-[#6b7c76] font-bold pl-2">Kabupaten / Kota</div>
              {MONTHS.map((m) => (
                <div key={m} className="flex-1 font-mono tracking-tight">{m.slice(0, 3)}</div>
              ))}
            </div>

            {/* Heatmap Rows */}
            <div className="divide-y divide-slate-100/40 text-[#6b7c76]">
              {normalizedGrid.map((row) => (
                <div key={row.regency} className="flex items-center py-0.5 hover:bg-slate-50/70 transition">
                  {/* Y-Axis Label */}
                  <div className="w-48 text-xs font-sans font-medium text-[#1a3c34] truncate pl-2 flex items-center gap-1.5" title={row.regency}>
                    <span className="w-1 h-3 rounded bg-[#2d6a4f] shrink-0"></span>
                    <span>{row.regency}</span>
                  </div>

                  {/* 12 Month Cells */}
                  {row.normValues.map((val, mIdx) => {
                    const cellColor = getHeatValueColor(val);
                    const rawVal = row.rawValues[mIdx];
                    return (
                      <div 
                        key={mIdx}
                        className={`flex-1 text-center py-2.5 mx-[2px] rounded-md transition duration-150 relative group cursor-help text-[10px] font-mono ${cellColor.bg}`}
                        style={{ backgroundOpacity: 0.9 }}
                      >
                        {val.toFixed(1)}

                        {/* Tooltip on cell hover */}
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block bg-[#1a3c34] text-white p-3 rounded-xl shadow-xl border border-slate-700 text-[10px] leading-relaxed z-50 w-44 pointer-events-none">
                          <p className="font-bold text-center border-b border-slate-700 pb-1 mb-1 text-[#f0f7f4]">{row.regency}</p>
                          <p className="flex justify-between">
                            <span className="text-slate-350">Bulan:</span>
                            <span>{MONTHS[mIdx]}</span>
                          </p>
                          <p className="flex justify-between">
                            <span className="text-slate-350">Luas Mentah:</span>
                            <span className="font-bold">{rawVal.toLocaleString("id-ID")} Ha</span>
                          </p>
                          <p className="flex justify-between border-t border-slate-700/50 mt-1 pt-1">
                            <span className="text-slate-350">Normalisasi:</span>
                            <span className="font-bold text-emerald-400">{(val * 100).toFixed(0)}%</span>
                          </p>
                        </div>

                      </div>
                    );
                  })}
                </div>
              ))}
            </div>

          </div>
        </div>

      </div>

      {/* Summary report */}
      <div id="variability-summary" className="bg-[#f0f7f4]/55 border border-[#e2e8e0] rounded-3xl p-6 shadow-sm">
        <h4 className="font-sans font-bold text-[#1a3c34] text-sm mb-4 flex items-center gap-2">
          <Activity className="w-5 h-5 text-[#2d6a4f]" />
          Temuan Pola Variabilitas Musim Tanam Jabar
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-650 leading-relaxed">
          <div>
            <h5 className="font-bold text-[#1a3c34] mb-1.5">• Kluster Pesisir Pantura (Karawang, Subang, Indramayu)</h5>
            <p className="text-[#6b7c76] pl-4 border-l border-[#2d6a4f]">
              Menunjukkan kemiripan waktu puncak panen di bulan Maret-April dan Juli-Agustus (warna hijau tua). Ini membuktikan sinkronisasi jadwal irigasi bendungan makro di pesisir utara untuk tanaman rentengan dan gadu. Masa minim panen (warna merah) dominan di bulan November-Desember.
            </p>
          </div>
          <div>
            <h5 className="font-bold text-[#1a3c34] mb-1.5">• Kluster Pegunungan Selatan (Cianjur, Garut, Tasikmalaya)</h5>
            <p className="text-[#6b7c76] pl-4 border-l border-[#2d6a4f]/60">
              Memiliki pola yang agak lebih tersebar rata (gradien kuning-hijau stabil dari Maret s.d Oktober). Karakteristik geografi perbukitan dengan aliran sungai lokal yang stabil/tadah hujan mandiri melahirkan fleksibilitas musim panen yang lebih bervariasi sepanjang tahun di lereng selatan.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
