/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  CheckSquare, 
  Leaf, 
  ShieldAlert, 
  Flame, 
  CheckCircle2, 
  HelpCircle,
  HelpCircle as QuestionIcon
} from "lucide-react";
import { MonthlyBMKG } from "../utils/preprocessing";

interface RiceSuitabilityViewProps {
  monthlyRainfall: MonthlyBMKG[];
}

export const RiceSuitabilityView: React.FC<RiceSuitabilityViewProps> = ({ monthlyRainfall }) => {
  
  // Categorization function
  const getSuitabilityDetails = (rain: number) => {
    if (rain < 50) {
      return {
        label: "Sangat Kritis / Kering",
        desc: "Kekurangan pasokan air, pembungaan berisiko tinggi fuso.",
        bg: "bg-[#fff5f5] border-[#f8d7da] text-[#e5383b]",
        badge: "bg-[#e5383b] text-white",
        icon: Flame,
        tag: "KRITIS"
      };
    } else if (rain >= 50 && rain < 100) {
      return {
        label: "Rendah",
        desc: "Butuh suplai pompa air atau aliran irigasi teknis bantuan.",
        bg: "bg-[#fff8f0] border-[#fbe9d0] text-[#c2843e]",
        badge: "bg-[#c2843e] text-white",
        icon: ShieldAlert,
        tag: "KURANG"
      };
    } else if (rain >= 100 && rain <= 200) {
      return {
        label: "Optimal",
        desc: "Masa air sangat ideal untuk pelumpuran sawah dan penanaman.",
        bg: "bg-[#f0f7f4] border-[#e2e8e0] text-[#1a3c34]",
        badge: "bg-[#2d6a4f] text-white",
        icon: Leaf,
        tag: "OPTIMAL"
      };
    } else {
      return {
        label: "Berlebih",
        desc: "Curah jenuh, waspada risiko banjir bandang di hilir pesisir.",
        bg: "bg-[#f0f4ff] border-[#d6e4ff] text-[#1a3c34]",
        badge: "bg-[#4361ee] text-white",
        icon: ShieldAlert,
        tag: "BERLEBIH"
      };
    }
  };

  return (
    <div id="suitability-view" className="space-y-6">
      
      {/* Explanation Banner */}
      <div id="suitability-banner" className="bg-[#f0f7f4] border border-[#e2e8e0] rounded-3xl p-6 shadow-sm flex items-start gap-4">
        <div className="bg-[#2d6a4f] text-white p-3 rounded-2xl shrink-0">
          <CheckSquare className="w-6 h-6" />
        </div>
        <div>
          <h3 className="font-sans font-bold text-[#1a3c34] text-base">Penilaian Kesesuaian Curah Hujan untuk Tanaman Padi</h3>
          <p className="text-xs text-[#2d6a4f]/85 mt-1 leading-relaxed">
            “Bulan dengan curah hujan optimal dapat menjadi indikasi awal periode tanam yang lebih sesuai, sedangkan bulan dengan curah hujan berlebih perlu diantisipasi karena berpotensi menimbulkan genangan atau gangguan aktivitas pertanian.”
          </p>
          <div className="flex gap-4 mt-3 text-[11px] text-[#2d6a4f] font-mono font-medium">
            <span>• Basah &amp; Lembap = Ideal Pembibitan</span>
            <span>• Kering = Sesuai Pematangan &amp; Panen</span>
          </div>
        </div>
      </div>

      {/* Heatmap Grid Cards (12 Months Grid with micro status cards) */}
      <div id="suitability-grid" className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {monthlyRainfall.map((m) => {
          const rain = m.total_curah_hujan;
          const conf = getSuitabilityDetails(rain);
          const Icon = conf.icon;
          
          return (
            <div 
              key={m.bulan_idx} 
              id={`suitability-card-${m.bulan_idx}`}
              className={`rounded-2xl p-5 border shadow-sm flex flex-col justify-between hover:scale-[1.02] hover:shadow-md transition-all duration-200 ${conf.bg}`}
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-sans font-bold text-[#1a3c34] text-base">{m.bulan_nama}</h4>
                  <span className={`text-[9px] font-bold font-mono px-2 py-0.5 rounded-full ${conf.badge}`}>
                    {conf.tag}
                  </span>
                </div>

                <div className="flex items-center gap-3 my-3">
                  <div className="bg-white/90 p-2.5 rounded-xl shadow-xs shrink-0">
                    <Icon className="w-6 h-6 text-slate-700 stroke-[1.8]" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-[#6b7c76] uppercase tracking-wider block">Total RR</span>
                    <strong className="text-[#1a3c34] text-base font-mono">{rain} mm</strong>
                  </div>
                </div>

                <p className="text-[11px] text-slate-600 leading-relaxed mt-2 pl-1 border-l border-[#e2e8e0]">
                  {conf.desc}
                </p>
              </div>

              {/* Monthly Secondary Stats */}
              <div className="mt-4 pt-3 border-t border-slate-100/60 grid grid-cols-2 text-[10px] text-[#6b7c76] text-center font-mono font-medium">
                <div className="border-r border-slate-100/60">
                  <p className="text-slate-400">Suhu Avg</p>
                  <p className="text-slate-700 mt-0.5">{m.avg_suhu_avg}°C</p>
                </div>
                <div>
                  <p className="text-slate-400">Kelembapan</p>
                  <p className="text-slate-700 mt-0.5">{m.avg_kelembapan}%</p>
                </div>
              </div>

            </div>
          );
        })}
           {/* Advisory & Decision Support Matrix */}
      <div id="suitability-matrix" className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm">
        <h4 className="font-sans font-bold text-[#1a3c34] text-base mb-4 flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-[#2d6a4f]" />
          Rekomendasi Rencana Masa Tanam Terintegrasi
        </h4>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 text-[#6b7c76] font-semibold border-b border-slate-200">
                <th className="p-3">Rentang Curah Hujan</th>
                <th className="p-3">Kategori</th>
                <th className="p-3">Saran Kegiatan Pola Tanam</th>
                <th className="p-3">Kebutuhan Irigasi</th>
                <th className="p-3 text-right">Potensi Hasil Panen</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[#6b7c76] leading-relaxed">
              <tr>
                <td className="p-4 font-mono font-bold text-[#e5383b]">&lt; 50 mm</td>
                <td className="p-4"><span className="bg-[#fff5f5] text-[#e5383b] px-2 py-0.5 rounded font-medium text-[10px]">Sangat Kritis</span></td>
                <td className="p-4">Bera (istirahatkan lahan), menanam palawija (jagung, kedelai), atau pemeliharaan saluran tersier.</td>
                <td className="p-4 text-[#e5383b] font-bold">MUTLAK DIPOMPA / IRIGASI WADUK</td>
                <td className="p-4 text-right font-medium">Sangat Rendah (Risiko Fuso)</td>
              </tr>
              <tr>
                <td className="p-4 font-mono font-bold text-[#c2843e]">50 s.d 100 mm</td>
                <td className="p-4"><span className="bg-[#fff8f0] text-[#c2843e] px-2 py-0.5 rounded font-medium text-[10px]">Rendah</span></td>
                <td className="p-4">Sesuai untuk padi gogo lahan kering atau persiapan persemaian padi sawah pendahuluan.</td>
                <td className="p-4">Suplesi Tinggi (Pompa/Sumur Bor)</td>
                <td className="p-4 text-right font-medium text-slate-600">Sedang (Terbatas)</td>
              </tr>
              <tr className="bg-[#f0f7f4]/40">
                <td className="p-4 font-mono font-bold text-[#2d6a4f]">100 s.d 200 mm</td>
                <td className="p-4"><span className="bg-[#f0f7f4] text-[#2d6a4f] px-2 py-0.5 rounded font-bold text-[10px]">Optimal</span></td>
                <td className="p-4">Sangat direkomendasikan untuk membajak, melumpurkan tanah, & pemindahan bibit padi (tanam).</td>
                <td className="p-4 text-[#2d6a4f] font-bold">ALAMIAH (CUKUP AIR HUJAN)</td>
                <td className="p-4 text-right text-[#2d6a4f] font-bold">Sangat Tinggi (Hasil Maksimal)</td>
              </tr>
              <tr>
                <td className="p-4 font-mono font-bold text-[#4361ee]">&gt; 200 mm</td>
                <td className="p-4"><span className="bg-[#f0f4ff] text-[#4361ee] px-2 py-0.5 rounded font-medium text-[10px]">Berlebih</span></td>
                <td className="p-4">Padi sawah fase vegetatif akhir s.d pengisian bulir. Kendalikan pintu air utama menghindari genangan.</td>
                <td className="p-4 text-[#4361ee] font-bold">DRAINASE AKTIF & FLOOD CONTROL</td>
                <td className="p-4 text-right font-medium">Sedang-Tinggi (Kerawanan Banjir)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>   </div>

    </div>
  );
};
