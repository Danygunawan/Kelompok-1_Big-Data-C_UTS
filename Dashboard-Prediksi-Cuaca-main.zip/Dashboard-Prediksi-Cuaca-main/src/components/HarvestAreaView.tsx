/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { 
  Sprout, 
  Map, 
  Filter, 
  Search, 
  CheckSquare, 
  X,
  ListOrdered,
  Sparkles,
  BarChart,
  Grid
} from "lucide-react";
import { 
  AreaChart, 
  Area, 
  BarChart as RechartsBarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { MONTHS } from "../data/datasets";

interface HarvestAreaViewProps {
  harvestData: Record<string, number[]>;
}

export const HarvestAreaView: React.FC<HarvestAreaViewProps> = ({ harvestData }) => {
  // Region lists
  const regencies = useMemo(() => Object.keys(harvestData).sort(), [harvestData]);
  
  // States
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRegencies, setSelectedRegencies] = useState<string[]>([
    "Kab. Indramayu",
    "Kab. Karawang",
    "Kab. Subang",
    "Kab. Cianjur"
  ]);

  // Handle Select All / Deselect All
  const handleSelectAll = () => {
    setSelectedRegencies(regencies);
  };

  const handleDeselectAll = () => {
    setSelectedRegencies(["Kab. Indramayu"]); // Keep at least one to prevent empty state crashes
  };

  const handleToggleRegency = (regency: string) => {
    if (selectedRegencies.includes(regency)) {
      if (selectedRegencies.length > 1) {
        setSelectedRegencies(selectedRegencies.filter(r => r !== regency));
      }
    } else {
      setSelectedRegencies([...selectedRegencies, regency]);
    }
  };

  // Search filter
  const filteredRegenciesList = regencies.filter((r) => 
    r.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Computed data 1: Total Jabar Harvest monthly (independent of filter, showing macro trend)
  const jabarMonthlyTotal = useMemo(() => {
    const monthlySum = Array(12).fill(0);
    (Object.values(harvestData) as number[][]).forEach((row) => {
      row.forEach((v, monthIdx) => {
        monthlySum[monthIdx] += v;
      });
    });
    return MONTHS.map((m, idx) => ({
      name: m.slice(0, 3),
      MonthName: m,
      "Luas Panen (Ha)": monthlySum[idx]
    }));
  }, [harvestData]);

  // Computed data 2: Filtered regencies monthly comparison
  const filteredMonthlyData = useMemo(() => {
    return MONTHS.map((m, monthIdx) => {
      const dataPoint: any = {
        name: m.slice(0, 3),
        MonthName: m
      };
      selectedRegencies.forEach((regency) => {
        dataPoint[regency] = harvestData[regency]?.[monthIdx] || 0;
      });
      return dataPoint;
    });
  }, [harvestData, selectedRegencies]);

  // Computed data 3: Rankings of all districts (annual total)
  const regencyRankings = useMemo(() => {
    return (Object.entries(harvestData) as [string, number[]][]).map(([regency, values]) => {
      const total = values.reduce((a, b) => a + b, 0);
      const maxVal = Math.max(...values);
      const peakMonthIdx = values.indexOf(maxVal);
      return {
        regency,
        total,
        peakMonth: MONTHS[peakMonthIdx],
        values
      };
    }).sort((a, b) => b.total - a.total);
  }, [harvestData]);

  // Top 10 highest-producing districts
  const top10RegenciesChart = useMemo(() => {
    return regencyRankings.slice(0, 10).map((r) => ({
      name: r.regency.replace("Kab. ", "K. "),
      "Total Luas Panen (Ha)": r.total
    }));
  }, [regencyRankings]);

  // Distinct colors array for custom district lines (Natural & Elegant tones)
  const lineColors = [
    "#2d6a4f", "#1a4d4d", "#c2843e", "#708d81", "#d97706",
    "#7c3aed", "#db2777", "#4b5563", "#0891b2", "#84cc16"
  ];

  return (
    <div id="harvest-area-view" className="space-y-6">

      {/* Top Section: Overall West Java harvest Area and Top 10 bar */}
      <div id="macro-harvest-trends" className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        
        {/* West Java Total Harvest Line Chart */}
        <div className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-sans font-bold text-[#1a3c34] text-base flex items-center gap-2">
              <Sprout className="w-5 h-5 text-[#2d6a4f]" />
              Tren Bulanan Total Luas Panen Padi Prov. Jawa Barat 2025
            </h3>
            <p className="text-xs text-[#6b7c76] mt-1">
              Data akumulatif luas sawah padi yang dipanen di seluruh Jawa Barat (BPS) memperlihatkan siklus puncak panen raya ganda.
            </p>
          </div>

          <div className="h-72 w-full mt-6 text-xs select-none">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={jabarMonthlyTotal} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorHarvest" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2d6a4f" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#2d6a4f" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" tickLine={false} />
                <YAxis stroke="#94a3b8" tickLine={false} />
                <Tooltip />
                <Area 
                  name="Luas Panen (Ha)" 
                  type="monotone" 
                  dataKey="Luas Panen (Ha)" 
                  stroke="#2d6a4f" 
                  strokeWidth={2.5} 
                  fillOpacity={1} 
                  fill="url(#colorHarvest)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          
          <p className="text-[10px] text-slate-400 mt-2 text-center italic">
            *Dua puncak panen terlihat jelas: puncak utama di Maret-April (Rendengan) dan puncak kedua di Juli-Agustus (Gadu).
          </p>
        </div>

        {/* Top 10 Regencies Chart */}
        <div className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-sans font-bold text-[#1a3c34] text-base flex items-center gap-2">
              <BarChart className="w-5 h-5 text-[#1a4d4d]" />
              10 Kabupaten/Kota Luas Panen Terbesar Jawa Barat 2025
            </h3>
            <p className="text-xs text-[#6b7c76] mt-1">
              Visualisasi persaingan daerah produsen pangan utama di tatanan Jawa Barat selama kurun waktu 12 bulan.
            </p>
          </div>

          <div className="h-72 w-full mt-6 text-xs select-none">
            <ResponsiveContainer width="100%" height="100%">
              <RechartsBarChart data={top10RegenciesChart} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" tickLine={false} />
                <YAxis stroke="#94a3b8" tickLine={false} />
                <Tooltip />
                <Bar name="Luas Panen Padi (Ha)" dataKey="Total Luas Panen (Ha)" fill="#1a4d4d" radius={[4, 4, 0, 0]} />
              </RechartsBarChart>
            </ResponsiveContainer>
          </div>

          <p className="text-[10px] text-slate-400 mt-2 text-center italic">
            *Kab. Indramayu memimpin sebagai "Lumbung Padi Nasional", diikuti oleh Kab. Karawang dan Kab. Subang.
          </p>
        </div>

      </div>

      {/* Interactive Section 2: Regional Filters & Selected District Comparative Line Chart */}
      <div id="interactive-regional-analytics" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Interactive Checkbox List and Region Search */}
        <div className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm flex flex-col h-[500px]">
          <h4 className="font-sans font-bold text-[#1a3c34] text-sm flex items-center gap-2">
            <Filter className="w-4 h-4 text-[#2d6a4f]" />
            Pilih Wilayah Jawa Barat
          </h4>
          <p className="text-[11px] text-[#6b7c76] mt-0.5 mb-4">Cari dan pilih kabupaten/kota untuk merender grafik dinamika luas panen</p>

          <div className="relative mb-3">
            <Search className="w-4 h-4 text-[#6b7c76] absolute left-3 top-3" />
            <input 
              type="text" 
              placeholder="Cari Kabupaten/Kota..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs font-sans pl-9 pr-4 py-2 border border-slate-200 rounded-xl focus:border-[#2d6a4f] focus:outline-hidden"
            />
          </div>

          <div className="flex gap-2 mb-3">
            <button 
              onClick={handleSelectAll}
              className="flex-1 py-1 text-[10px] font-sans font-medium bg-[#f0f7f4] text-[#2d6a4f] rounded-lg hover:bg-[#e2e8e0] border border-[#e2e8e0] transition cursor-pointer"
            >
              Pilih Semua
            </button>
            <button 
              onClick={handleDeselectAll}
              className="flex-1 py-1 text-[10px] font-sans font-medium bg-slate-50 text-slate-600 rounded-lg hover:bg-slate-100 border border-slate-200 transition cursor-pointer"
            >
              Reset Filter
            </button>
          </div>

          {/* Regency Checkbox List Area */}
          <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 divide-y divide-slate-50 scrollbar-thin">
            {filteredRegenciesList.map((regency) => {
              const checked = selectedRegencies.includes(regency);
              return (
                <div 
                  key={regency} 
                  onClick={() => handleToggleRegency(regency)}
                  className={`flex items-center gap-2.5 px-2.5 py-2 rounded-lg cursor-pointer transition text-xs ${
                    checked ? "bg-[#f0f7f4]/50 hover:bg-[#f0f7f4]" : "hover:bg-slate-50 text-slate-650"
                  }`}
                >
                  <input 
                    type="checkbox" 
                    checked={checked}
                    readOnly
                    className="rounded border-slate-300 text-[#2d6a4f] focus:ring-[#2d6a4f] w-3.5 h-3.5 accent-[#2d6a4f] cursor-pointer"
                  />
                  <span className={`${checked ? "font-semibold text-[#1a3c34]" : ""}`}>{regency}</span>
                </div>
              );
            })}
          </div>

          {/* Selected count label */}
          <div className="mt-4 pt-3 border-t border-slate-100 flex justify-between items-center text-[11px] text-[#6b7c76]">
            <span>Terpilih: <strong>{selectedRegencies.length}</strong> wilayah</span>
            {selectedRegencies.length > 6 && (
              <span className="text-[#c2843e] font-medium">Batas visual disarankan &lt; 6</span>
            )}
          </div>
        </div>

        {/* Selected Area - Multi-line chart compares crop patterns */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm flex flex-col justify-between h-[500px]">
          <div>
            <h4 className="font-sans font-bold text-[#1a3c34] text-base">
              Rincian Perkembangan Dinamika Luas Panen (Wilayah Terpilih)
            </h4>
            <p className="text-xs text-[#6b7c76] mt-1">
              Kurva perbandingan panen padi bulanan 2025 untuk daerah yang dipilih pada daftar filter kuantitatif.
            </p>
          </div>

          <div className="h-80 w-full mt-6 text-xs select-none">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={filteredMonthlyData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" tickLine={false} />
                <YAxis stroke="#94a3b8" tickLine={false} />
                <Tooltip />
                <Legend iconType="circle" wrapperStyle={{ fontSize: 10 }} />
                
                {selectedRegencies.map((regency, index) => (
                  <Line 
                     key={regency}
                     name={regency.replace("Kab. ", "K. ")}
                     type="monotone"
                     dataKey={regency}
                     stroke={lineColors[index % lineColors.length]}
                     strokeWidth={2.5}
                     dot={{ r: 3 }}
                     activeDot={{ r: 5 }}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-[#f0f7f4]/60 p-3.5 border border-[#e2e8e0] rounded-2xl flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-[#2d6a4f] shrink-0 mt-0.5" />
            <p className="text-[11px] text-[#1a3c34] leading-relaxed">
              <strong>Analisis Singkat:</strong> Perhatikan pergeseran bulan puncak antar wilayah. Daerah pantai utara (seperti Indramayu, Subang, Karawang) memiliki waktu puncak yang relatif bersamaan karena keselarasan saluran irigasi bendung Jatiluhur, sedangkan wilayah pegunungan (seperti Garut, Sukabumi) memiliki variasi tanam yang tersebar rata sepanjang tahun.
            </p>
          </div>
        </div>

      </div>

      {/* Comprehensive tabulated data rankings */}
      <div id="full-rankings-table" className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm">
        <h4 className="font-sans font-bold text-[#1a3c34] text-base mb-2 flex items-center gap-2">
          <ListOrdered className="w-5 h-5 text-[#2d6a4f]" />
          Ranking Total Luas Panen Padi Se-Jawa Barat 2025
        </h4>
        <p className="text-xs text-[#6b7c76] mb-4">
          Tabel performa pertanian seluruh kabupaten/kota diurutkan dari luas panen tahunan akumulatif terbesar (Sumber: Olah Data BPS).
        </p>

        <div className="max-h-96 overflow-y-auto border border-slate-100 rounded-2xl scrollbar-thin">
          <table className="w-full text-left border-collapse text-xs select-none">
            <thead>
              <tr className="bg-slate-50 text-slate-500 border-b border-slate-200">
                <th className="p-3 font-semibold text-center w-12">Rank</th>
                <th className="p-3 font-semibold">Kabupaten/Kota</th>
                <th className="p-3 font-semibold text-right">Luas Panen (Ha)</th>
                <th className="p-3 font-semibold text-right">Rata-Rata Bulanan</th>
                <th className="p-3 font-semibold text-right">Bulan Puncak (Peak)</th>
                <th className="p-3 font-semibold text-right">Luas Puncak (Ha)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[#6b7c76]">
              {regencyRankings.map((row, index) => {
                const avg = Math.round(row.total / 12);
                const maxVal = Math.max(...row.values);
                const peakMonthIdx = row.values.indexOf(maxVal);
                const peakVal = row.values[peakMonthIdx];
                
                return (
                  <tr key={row.regency} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3 font-mono font-bold text-center text-slate-400">
                      {index + 1 === 1 ? (
                        <span className="bg-yellow-500 text-white font-semibold py-0.5 px-2 rounded-full text-[10px]">1</span>
                      ) : index + 1 === 2 ? (
                        <span className="bg-[#1a4d4d] text-white font-semibold py-0.5 px-2 rounded-full text-[10px]">2</span>
                      ) : index + 1 === 3 ? (
                        <span className="bg-amber-600 text-white font-semibold py-0.5 px-2 rounded-full text-[10px]">3</span>
                      ) : (
                        index + 1
                      )}
                    </td>
                    <td className="p-3 font-sans font-medium text-[#1a3c34]">{row.regency}</td>
                    <td className="p-3 text-right font-mono font-semibold text-[#2d6a4f]">{row.total.toLocaleString("id-ID")}</td>
                    <td className="p-3 text-right font-mono text-slate-500">{avg.toLocaleString("id-ID")}</td>
                    <td className="p-3 text-[#1a4d4d] text-right font-medium">{MONTHS[peakMonthIdx]}</td>
                    <td className="p-3 text-right font-mono text-slate-500">{peakVal.toLocaleString("id-ID")}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
