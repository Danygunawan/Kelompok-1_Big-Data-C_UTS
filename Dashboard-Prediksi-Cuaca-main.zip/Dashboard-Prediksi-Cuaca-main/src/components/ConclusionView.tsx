/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  FileText, 
  Lightbulb, 
  CheckCircle, 
  ArrowUpRight, 
  AlertCircle,
  HelpCircle
} from "lucide-react";

export const ConclusionView: React.FC = () => {
  return (
    <div id="conclusion-view" className="space-y-6">

      {/* Structured key conclusions card */}
      <div id="conclusion-grid" className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Conclusions Column */}
        <div className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-sans font-bold text-[#1a3c34] text-base mb-4 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-[#2d6a4f]" />
              Kesimpulan Hasil Analisis Proyek 2025
            </h3>

            <div className="space-y-4">
              <div className="flex gap-3 leading-relaxed text-xs">
                <span className="w-6 h-6 rounded-lg bg-[#f0f7f4] text-[#2d6a4f] font-bold flex items-center justify-center shrink-0 mt-0.5">1</span>
                <div>
                  <strong className="text-[#1a3c34] block">Fluktuasi Curah Hujan Bulanan</strong>
                  <span className="text-[#6b7c76]">
                    Curah hujan di Jawa Barat (pencatatan Stasiun Klimatologi Bogor) tahun 2025 menunjukkan pola bulanan yang bervariasi dengan musim basah terpusat pada November-Januari dan Maret-April, serta periode kering terekam mendalam pada Juni-September.
                  </span>
                </div>
              </div>

              <div className="flex gap-3 leading-relaxed text-xs">
                <span className="w-6 h-6 rounded-lg bg-[#f0f7f4] text-[#2d6a4f] font-bold flex items-center justify-center shrink-0 mt-0.5">2</span>
                <div>
                  <strong className="text-[#1a3c34] block">Zona Kebutuhan Air Padi</strong>
                  <span className="text-[#6b7c76]">
                    Beberapa bulan memiliki curah hujan kriteria optimal (100–200 mm) yang sangat selaras untuk mengawali penanganan tanah padi sawah, sedangkan bulan-bulan bercurah ekstrim tinggi (&gt; 200 mm) berpotensi memicu genangan air berlebih di hulu pesisir utara.
                  </span>
                </div>
              </div>

              <div className="flex gap-3 leading-relaxed text-xs">
                <span className="w-6 h-6 rounded-lg bg-[#f0f7f4] text-[#2d6a4f] font-bold flex items-center justify-center shrink-0 mt-0.5">3</span>
                <div>
                  <strong className="text-[#1a3c34] block">Dinamika & Dominasi Spasial Luas Panen</strong>
                  <span className="text-[#6b7c76]">
                    Luas panen padi di seluruh Jabar berbeda drastis antar bulan dan antar wilayah. Daerah basah pesisir pantai utara seperti <strong>Indramayu, Karawang, dan Subang</strong>, bersanding dengan <strong>Cianjur</strong> di dataran tinggi, muncul mutlak sebagai kabupaten lumbung pangan raksasa dengan total luas panen akumulatif tahunan tertinggi.
                  </span>
                </div>
              </div>

              <div className="flex gap-3 leading-relaxed text-xs">
                <span className="w-6 h-6 rounded-lg bg-[#f0f7f4] text-[#2d6a4f] font-bold flex items-center justify-center shrink-0 mt-0.5">4</span>
                <div>
                  <strong className="text-[#1a3c34] block">Korelasi Lags Sebagai Indikasi Awal</strong>
                  <span className="text-[#6b7c76]">
                    Pola asosiasi waktu tunda (lag korelasi) curah hujan terhadap luas panen padi memberikan indikasi korelasi awal yang bersiklus positif tinggi pada rentang Lag 3 (jeda waktu pertumbuhan 3 bulan). Akan tetapi, analisis ini bersifat regional-indikatif karena keterbatasan rentang data 12 bulan.
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Future Developments Column */}
        <div className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-sans font-bold text-[#1a3c34] text-base mb-4 flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-[#c2843e]" />
              Arah Potensi Pengembangan Sistem Dashboard
            </h3>

            <div className="space-y-3.5 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-[#e2e8e0]/65 flex gap-2.5 items-start">
                <ArrowUpRight className="w-4 h-4 text-[#2d6a4f] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-[#1a3c34] block">Himpunan Data Multi-Tahun (Long-series)</strong>
                  <p className="text-[#6b7c76] mt-0.5">Menambah rentang data historis beberapa tahun ke belakang, misalnya kurun waktu 2020–2025, guna memperkuat pembuktian statistik deret waktu (Time Series Cointegration) dan deteksi anomali El Nino.</p>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-[#e2e8e0]/65 flex gap-2.5 items-start">
                <ArrowUpRight className="w-4 h-4 text-[#2d6a4f] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-[#1a3c34] block">Integrasi Jaringan Multi-Stasiun BMKG</strong>
                  <p className="text-[#6b7c76] mt-0.5">Menambahkan parameter pencatatan stasiun BMKG meteorologi lokal lain (seperti stasiun Jatiwangi, Majalengka, Cirebon) agar model asimilasi curah hujan lebih representatif dan akurat mewakili mikroklimat sela tiap-tiap wilayah kabupaten.</p>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-[#e2e8e0]/65 flex gap-2.5 items-start">
                <ArrowUpRight className="w-4 h-4 text-[#2d6a4f] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-[#1a3c34] block">Ekspansi Variabel Sosio-Agronomis Terpadu</strong>
                  <p className="text-[#6b7c76] mt-0.5">Memasukkan faktor non-cuaca yang berpengaruh tinggi: kapasitas debit irigasi waduk, asupan pupuk, hama penyakit tanaman, bencana banjir/kekeringan lokal, hingga angka kuantitas produksi padi murni (ton GKG).</p>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-[#e2e8e0]/65 flex gap-2.5 items-start">
                <ArrowUpRight className="w-4 h-4 text-[#2d6a4f] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-[#1a3c34] block">Pengembangan Model Prediksi Berbasis AI / Machine Learning</strong>
                  <p className="text-[#6b7c76] mt-0.5">Membangun model kecerdasan buatan (seperti LSTM atau XGBoost) untuk melancarkan prognosis/estimasi luas panen serta merilis sistem rekomendasi kalender musim tanam dinamis bagi para petani Jawa Barat.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Advisory warning note at the bottom */}
      <div id="advisory-caution" className="bg-[#1a3c34] text-white rounded-3xl p-6 flex gap-4 items-start shadow-sm border border-[#2d6a4f]">
        <HelpCircle className="w-5 h-5 text-[#f0f7f4] shrink-0 mt-0.5 animate-pulse" />
        <div className="text-xs text-[#f0f7f4]/90 leading-relaxed">
          <h4 className="font-semibold text-white">Catatan Bagi Pengamat Kebijakan (Policy Maker Recommendation)</h4>
          <p className="mt-1">
            Meningkatnya fenomena perubahan iklim global memaksa rekayasa agrikultur harus dipandu oleh bukti-bukti analisis data taktis (Data-Driven Agriculture). Melahui pertautan data BMKG dan BPS ini, pemerintah daerah dapat bersama-sama mengoptimalkan mitigasi gawat darurat air di bulan kemarau kering, memberikan subsidi bibit toleran kekeringan tepat sasaran, serta merevitalisasi bendung irigasi primer di tiga poros lumbung padi terbesar (Pantura Barat) demi melestarikan stabilitas ketahanan pangan regional maupun nasional.
          </p>
        </div>
      </div>

    </div>
  );
};
