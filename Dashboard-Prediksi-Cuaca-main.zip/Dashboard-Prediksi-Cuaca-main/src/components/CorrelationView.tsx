/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from "react";
import { BarChart2, AlertTriangle, ShieldCheck, HelpCircle } from "lucide-react";
import { generateAllCorrelations, RegencyCorr } from "../utils/preprocessing";
import { MONTHS } from "../data/datasets";

interface CorrelationViewProps {
  monthlyRainfall: number[]; // 12 elements (Jan-Dec) total curah hujan
  harvestData: Record<string, number[]>; // Regency -> 12 monthly values
}

export const CorrelationView: React.FC<CorrelationViewProps> = ({ 
  monthlyRainfall, 
  harvestData 
}) => {
  
  // Compute correlations dynamically using our utility function
  const correlations = useMemo(() => {
    return generateAllCorrelations(monthlyRainfall, harvestData).sort((a, b) => 
      a.regency.localeCompare(b.regency)
    );
  }, [monthlyRainfall, harvestData]);

  // Color mapper for Pearson r (-1.0 to +1.0)
  // Positive correlations = Emerald/Teal, Negatives = Rose/Red, Neutral = Light grey
  const getCorrCellColor = (r: number) => {
    if (r >= 0.5) return "bg-[#2d6a4f] text-white font-bold";
    if (r >= 0.2) return "bg-[#f0f7f4] text-[#2d6a4f] font-medium border border-[#e2e8e0]";
    if (r > -0.2 && r < 0.2) return "bg-slate-50 text-slate-450 border border-[#e2e8e0]/60";
    if (r <= -0.5) return "bg-[#e5383b] text-white font-bold";
    return "bg-[#fff5f5] text-[#e5383b] font-medium border border-[#f8d7da]";
  };

  return (
    <div id="correlation-view" className="space-y-6">

      {/* Validity reminder note */}
      <div id="validity-warning" className="bg-[#fff8f0] border border-[#fbe9d0] rounded-3xl p-5 flex items-start gap-4">
        <AlertTriangle className="w-5 h-5 text-[#c2843e] shrink-0 mt-0.5" />
        <div className="text-xs">
          <h4 className="font-sans font-bold text-[#c2843e] leading-none">Pernyataan Validitas & Batasan Korelasi</h4>
          <p className="text-[#a4713c] mt-1.5 leading-relaxed">
            “Data curah hujan berasal dari satu stasiun klimatologi di Bogor, sehingga hasil korelasi bersifat regional dan indikatif.” Korelasi linier Pearson yang diperoleh harus ditafsirkan sebagai indikasi awal hubungan trend agroklimatologi makro, karena panjang deret data baru mencakup 12 titik bulan sepanjang tahun 2025.
          </p>
        </div>
      </div>

      {/* Lag correlation details explaining how crop cycles align */}
      <div className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm">
        <h3 className="font-sans font-bold text-[#1a3c34] text-base mb-2 flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-[#2d6a4f]" />
          Memahami Time-Lag (Keterlambatan Waktu) Curah Hujan vs Panen
        </h3>
        <p className="text-xs text-[#6b7c76] mb-4 leading-relaxed">
          Padi sawah membutuhkan waktu tumbuh sekitar 3 s.d 4 bulan. Oleh karena itu, ketersediaan air (curah hujan) di bulan awal penanaman akan mempengaruhi areal luas panen di beberapa bulan setelahnya.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs font-sans text-slate-650">
          <div className="p-3.5 bg-slate-50 rounded-xl border border-[#e2e8e0]/60">
            <strong className="text-[#1a3c34] block mb-0.5">Lag 0 Bulan (Instan)</strong>
            <p className="text-[11px] text-[#6b7c76]">Curah hujan bulan <em>t</em> dianalisis langsung dengan luas panen bulan <em>t</em>. Biasanya berasosiasi lemah karena padi tidak langsung dipanen saat hujan turun.</p>
          </div>
          <div className="p-3.5 bg-slate-50 rounded-xl border border-[#e2e8e0]/60">
            <strong className="text-[#1a3c34] block mb-0.5 font-bold">Lag 1 Bulan</strong>
            <p className="text-[11px] text-[#6b7c76] font-normal">Mendeteksi dampak hujan 1 bulan sebelum panen. Menjelang fase pematangan biji padi (stadia generatif akhir).</p>
          </div>
          <div className="p-3.5 bg-slate-50 rounded-xl border border-[#e2e8e0]/60">
            <strong className="text-[#1a3c34] block mb-0.5">Lag 2 Bulan</strong>
            <p className="text-[11px] text-[#6b7c76]">Menelaah pengaruh suplai air hujan pada saat tanaman padi memasuki fase pengisian bulir padi (fase reproduktif aktif).</p>
          </div>
          <div className="p-3.5 bg-[#f0f7f4] border border-[#e2e8e0] rounded-xl">
            <strong className="text-[#1a3c34] block mb-0.5 font-bold">Lag 3 Bulan (Paling Penting)</strong>
            <p className="text-[11px] text-[#2d6a4f]">Menilai hubungan ketersediaan air pada masa pembajakan sawah, pelumpuran, & persemaian bibit (tanam) terhadap keberhasilan luas panen di bulan ke-3.</p>
          </div>
        </div>
      </div>

      {/* Matrix Table Correlation list */}
      <div id="correlation-matrix-card" className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm overflow-hidden">
        
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-6">
          <div>
            <h4 className="font-sans font-bold text-[#1a3c34] text-sm">Matriks Korelasi Curah Hujan vs Luas Panen (Lag 0 s.d 3)</h4>
            <p className="text-[11px] text-[#6b7c76] mt-0.5">Nilai cell: Koefisien Pearson (r). Arah hubungan: biru-hijau (positif), jingga-merah (negatif).</p>
          </div>

          {/* Color bar legend */}
          <div className="flex items-center gap-1.5 text-[9px] text-[#6b7c76] font-mono select-none">
            <span>Korelasi Negatif (-1.0)</span>
            <span className="w-3 h-3 rounded bg-[#e5383b]"></span>
            <span className="w-3 h-3 rounded bg-[#fff5f5]"></span>
            <span className="w-3 h-3 rounded bg-slate-50"></span>
            <span className="w-3 h-3 rounded bg-[#f0f7f4]"></span>
            <span className="w-3 h-3 rounded bg-[#2d6a4f]"></span>
            <span>Korelasi Positif (+1.0)</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <div className="min-w-[700px] space-y-1.5">
            {/* Header */}
            <div className="flex items-center text-center font-sans font-semibold text-slate-500 text-[10px] uppercase border-b border-slate-200 pb-2">
              <div className="w-56 text-left text-[#6b7c76] font-bold pl-2">Kabupaten / Kota</div>
              <div className="flex-1 font-mono">Lag 0 (Bulan t)</div>
              <div className="flex-1 font-mono">Lag 1 (Bulan t-1)</div>
              <div className="flex-1 font-mono font-bold text-[#1a3c34]">Lag 2 (Bulan t-2)</div>
              <div className="flex-1 font-mono font-bold text-[#2d6a4f]">Lag 3 (Bulan t-3)</div>
              <div className="w-36 text-right pr-2">Arah Dominan</div>
            </div>

            {/* Rows */}
            <div className="divide-y divide-slate-100/40 text-[#6b7c76]">
              {correlations.map((row) => {
                // Find primary / highest absolute correlation
                const lagNames = ["Lag 0", "Lag 1", "Lag 2", "Lag 3"];
                const maxCorrLag = lagNames[row.max_lag];
                const relDir = row.max_val >= 0 ? "Positif" : "Negatif";
                const isStrong = Math.abs(row.max_val) >= 0.45;

                return (
                  <div key={row.regency} className="flex items-center py-1 hover:bg-slate-50/70 transition">
                    {/* Regency name */}
                    <div className="w-56 text-xs font-sans font-medium text-[#1a3c34] truncate pl-2 flex items-center gap-1">
                      <span className="w-1 h-3 rounded-full bg-[#2d6a4f] shrink-0"></span>
                      <span>{row.regency}</span>
                    </div>

                    {/* Cells values */}
                    <div className={`flex-1 text-center py-1.5 mx-1 rounded-md text-[11px] font-mono ${getCorrCellColor(row.lag0)}`}>
                      {row.lag0.toFixed(2)}
                    </div>
                    <div className={`flex-1 text-center py-1.5 mx-1 rounded-md text-[11px] font-mono ${getCorrCellColor(row.lag1)}`}>
                      {row.lag1.toFixed(2)}
                    </div>
                    <div className={`flex-1 text-center py-1.5 mx-1 rounded-md text-[11px] font-mono ${getCorrCellColor(row.lag2)}`}>
                      {row.lag2.toFixed(2)}
                    </div>
                    <div className={`flex-1 text-center py-1.5 mx-1 rounded-md text-[11px] font-mono ${getCorrCellColor(row.lag3)}`}>
                      {row.lag3.toFixed(2)}
                    </div>

                    {/* Dominant label right */}
                    <div className="w-36 text-right pr-2 text-[10px] font-sans font-medium">
                      <span className={`px-2 py-0.5 rounded-full ${
                        row.max_val >= 0 
                          ? "bg-[#f0f7f4] text-[#2d6a4f] border border-[#e2e8e0]" 
                          : "bg-[#fff5f5] text-[#e5383b] border border-[#f8d7da]"
                      }`}>
                        {maxCorrLag} ({relDir})
                      </span>
                    </div>

                  </div>
                );
              })}
            </div>

          </div>
        </div>

      </div>

      {/* Detailed Interpretations box requested by the user */}
      <div id="correlation-interpretations" className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm">
        <h4 className="font-sans font-bold text-[#1a3c34] text-sm mb-4">Panduan Dasar Interpretasi Koefisien Korelasi (Pearson r)</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-650 leading-relaxed">
          <div className="space-y-2.5">
            <h5 className="font-bold text-[#2d6a4f] flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#2d6a4f]" />
              1. Makna Korelasi Positif (+)
            </h5>
            <p className="text-[#6b7c76] pl-5">
              “Korelasi positif berarti peningkatan curah hujan cenderung searah dengan luas panen pada lag tersebut.” Sebagai contoh, koefisien beras r = 0,55 pada Lag 3 berarti curah hujan yang melimpah 3 bulan sebelumnya selaras dengan luas panen yang ikut meningkat pesat pada bulan tersebut, merefleksikan suksesnya penyemaian lahan pertanian basah.
            </p>
          </div>

          <div className="space-y-2.5">
            <h5 className="font-bold text-[#e5383b] flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-[#e5383b]" />
              2. Makna Korelasi Negatif (-)
            </h5>
            <p className="text-[#6b7c76] pl-5">
              “Korelasi negatif berarti peningkatan curah hujan cenderung berlawanan arah dengan luas panen.” Sebagai contoh, koefisien r = -0.45 pada Lag 0 mengindikasikan bahwa hujan yang berlebih di bulan panen justru berasosiasi dengan penurunan luas panen, kemungkinan karena kendala banjir di pertengahan panen atau terhambatnya pengeringan bulir padi sawah.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
