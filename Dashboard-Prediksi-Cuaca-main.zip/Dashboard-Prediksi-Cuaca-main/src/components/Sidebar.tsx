/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  Sprout, 
  BarChart2, 
  Settings, 
  CloudRain, 
  CheckSquare, 
  Layers, 
  FileText, 
  Database, 
  Sliders, 
  Code,
  Info
} from "lucide-react";

interface SidebarProps {
  currentTab: string;
  setTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentTab, setTab }) => {
  const menuItems = [
    { id: "overview", label: "Overview", icon: Info },
    { id: "preprocessing", label: "Dataset & Preprocessing", icon: Settings },
    { id: "rainfall", label: "Curah Hujan (BMKG)", icon: CloudRain },
    { id: "suitability", label: "Kesesuaian Tanam", icon: CheckSquare },
    { id: "harvest", label: "Luas Panen Padi (BPS)", icon: Sprout },
    { id: "variability", label: "Variabilitas Wilayah", icon: Sliders },
    { id: "correlation", label: "Asosiasi & Lag Korelasi", icon: BarChart2 },
    { id: "bigdata8v", label: "Prinsip 8V Big Data", icon: Database },
    { id: "conclusions", label: "Kesimpulan & Rencana", icon: FileText },
    { id: "pythoncode", label: "Python Streamlit Assets", icon: Code },
  ];

  return (
    <aside id="sidebar-container" className="w-80 bg-[#1a4d4d] text-[#e8f3f1] flex flex-col border-r border-[#d4e2df] shrink-0 select-none shadow-sm">
      {/* Brand Header */}
      <div id="sidebar-brand" className="p-6 border-b border-[#256060] bg-[#256060]/30 flex items-center gap-3">
        <Sprout id="brand-icon" className="w-8 h-8 text-[#a8dadc] stroke-[2]" />
        <div>
          <h1 id="brand-title" className="font-sans font-bold text-lg leading-tight tracking-tight text-white">AgriClimate<span className="text-[#a8dadc]">Jabar</span></h1>
          <p id="brand-subtitle" className="text-[11px] font-mono text-[#a8dadc]/80 uppercase tracking-widest mt-0.5">Big Data Analytics 2025</p>
        </div>
      </div>

      {/* Navigation List */}
      <nav id="sidebar-nav" className="flex-1 overflow-y-auto p-4 space-y-1.5 scrollbar-thin scrollbar-thumb-[#256060]">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-item-${item.id}`}
              onClick={() => setTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 text-left cursor-pointer group ${
                isActive 
                  ? "bg-[#256060] text-white font-semibold border-l-4 border-[#a8dadc] rounded-l-none shadow-sm" 
                  : "hover:bg-[#256060]/45 text-[#e8f3f1]/75 hover:text-white"
              }`}
            >
              <Icon 
                id={`icon-nav-${item.id}`} 
                className={`w-5 h-5 shrink-0 transition-transform duration-200 ${
                  isActive ? "scale-105" : "group-hover:scale-105 opacity-80"
                }`} 
              />
              <span className="text-sm font-medium leading-none">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Footer info */}
      <div id="sidebar-footer" className="p-4 border-t border-[#256060] bg-[#1a4d4d] text-center">
        <div className="bg-[#256060]/40 rounded-xl p-3 border border-[#256060]/60">
          <p className="text-xs text-[#a8dadc] font-medium">Stasiun Klimatologi Bogor</p>
          <div className="flex items-center justify-center gap-1.5 mt-1 text-[10px] text-[#e8f3f1]/80 font-mono">
            <span className="w-2 h-2 rounded-full bg-[#a8dadc] animate-pulse"></span>
            <span>DATASET VERIFIED</span>
          </div>
        </div>
        <p className="text-[10px] text-[#e8f3f1]/40 font-mono mt-3">© 2026 AgriClimate Dashboard</p>
      </div>
    </aside>
  );
};
