/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  Database, 
  Zap, 
  Layers, 
  Trash2, 
  Sparkles, 
  Sliders, 
  ShieldCheck, 
  PieChart,
  Network
} from "lucide-react";

export const BigData8VView: React.FC = () => {
  const vData = [
    {
      title: "1. Volume (Ukuran Data)",
      icon: Database,
      color: "border-[#e2e8e0] bg-[#f0f7f4]/20 text-[#1a3c34]",
      iconColor: "text-[#2d6a4f] bg-[#f0f7f4]",
      text: "Menunjukkan jumlah baris data BMKG harian (365 hari observasi) dikombinasikan dengan matriks bulanan BPS dari seluruh 27 kabupaten/kota di Provinsi Jawa Barat. Penggabungan melambangkan keragaman basis data spasial-temporal."
    },
    {
      title: "2. Velocity (Kecepatan & Siklus)",
      icon: Zap,
      color: "border-[#e2e8e0] bg-[#f0f7f4]/20 text-[#1a3c34]",
      iconColor: "text-[#2d6a4f] bg-[#f0f7f4]",
      text: "Menggambarkan perbedaan laju aliran data: BMKG dicatat bertahap secara Harian (Tinggi), sedangkan BPS dicatat Bulanan (Lambat). Sistem mengompilasi Velocity dengan mengagregasikan data harian ke dalam simpul bulanan."
    },
    {
      title: "3. Variety (Keanekaragaman Form)",
      icon: Layers,
      color: "border-[#e2e8e0] bg-[#f0f7f4]/20 text-[#1a3c34]",
      iconColor: "text-[#2d6a4f] bg-[#f0f7f4]",
      text: "Menggabungkan dua ranah disiplin data yang sangat berbeda: Atmosferik / Meteorologis (Suhu, kelembapan, curah hujan BMKG) dengan Sosio-Agronomis (Luas panen padi BPS). Data diintegrasikan dalam satu canvas terpadu."
    },
    {
      title: "4. Veracity (Keandalan / Kebersihan)",
      icon: Trash2,
      color: "border-[#f8d7da] bg-[#fff5f5]/45 text-rose-950",
      iconColor: "text-[#e5383b] bg-[#fff5f5]",
      text: "Menguji validitas integritas data. Proses rekayasa membersihkan kode penanda BMKG seperti 8888 dan 9999 menjadi 'NaN', membuang baris ganda, mengoreksi struktur tanggal miring, & mengimputasi nilai kosong lewat interpolasi linier."
    },
    {
      title: "5. Value (Manfaat & Insight)",
      icon: Sparkles,
      color: "border-[#fbe9d0] bg-[#fff8f0]/45 text-amber-950",
      iconColor: "text-[#c2843e] bg-[#fff8f0]",
      text: "Menghasilkan keputusan strategis yang berharga: Mengidentifikasi batas bulan optimal tanam, daerah kritis defisit air, wilayah lumbung pangan murni (Indramayu, Karawang, Subang), serta penentuan jadwal tanam agroklimatologis."
    },
    {
      title: "6. Variability (Dinamika Fluktuasi)",
      icon: Sliders,
      color: "border-[#e2e8e0] bg-[#f0f7f4]/20 text-[#1a3c34]",
      iconColor: "text-[#2d6a4f] bg-[#f0f7f4]",
      text: "Menunjukkan perubahan polikromatis curah hujan bulanan yang fluktuatif (kemarau vs penghujan) serta mengilustrasikan perpindahan luas panen antar wilayah kabupaten/kota Jabar melalui heatmap normalisasi min-max."
    },
    {
      title: "7. Validity (Ketepatan Metodologi)",
      icon: ShieldCheck,
      color: "border-[#e2e8e0] bg-[#f0f7f4]/20 text-[#1a3c34]",
      iconColor: "text-[#2d6a4f] bg-[#f0f7f4]",
      text: "Mengharuskan penyelarasan resolusi sebelum komparasi dilakukan (menyamakan data cuaca harian BMKG menjadi aggregat bulanan agar setara dengan data rujukan bulanan BPS). Menghindari cacat logika statistik 'spurious correlation'."
    },
    {
      title: "8. Visualization (Daya Visualisasi)",
      icon: PieChart,
      color: "border-[#e2e8e0] bg-[#f0f7f4]/20 text-[#1a3c34]",
      iconColor: "text-[#2d6a4f] bg-[#f0f7f4]",
      text: "Mewujudkan data rumit dalam rupa tampilan interaktif yang rapih, elegan, & intuitif: grafik tren area Recharts, bar bento, heatmap korelasi lag, kriteria warna kebutuhan air tanaman, serta filter multivariat wilayah Jabar."
    }
  ];

  return (
    <div id="big-data-8v-view" className="space-y-6">
      
      {/* Intro Header */}
      <div id="bigdata-intro" className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#2d6a4f] text-white rounded-2xl"><Network className="w-6 h-6" /></div>
          <div>
            <h3 className="font-sans font-bold text-[#1a3c34] text-lg">Penerapan Prinsip 8V Big Data</h3>
            <p className="text-xs text-[#6b7c76] mt-0.5">Analisis bagaimana proyek agroklimatologi ini mengadopsi pilar rekayasa Big Data secara disiplin.</p>
          </div>
        </div>
      </div>

      {/* Grid of cards */}
      <div id="eight-v-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {vData.map((v, idx) => {
          const IconComponent = v.icon;
          return (
            <div 
              key={idx} 
              id={`eight-v-card-${idx}`}
              className={`rounded-2xl p-5 border shadow-xs flex flex-col justify-between hover:scale-[1.01] hover:shadow-md transition-all duration-200 ${v.color}`}
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-sans font-bold text-[#1a3c34] text-sm leading-tight">{v.title}</h4>
                  <div className={`p-2 rounded-xl ${v.iconColor}`}>
                    <IconComponent className="w-5 h-5 shrink-0 stroke-[1.8]" />
                  </div>
                </div>

                <p className="text-[11px] text-[#6b7c76] leading-relaxed font-sans">
                  {v.text}
                </p>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
