/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  Settings, 
  ArrowRight, 
  Database, 
  Trash2, 
  CheckCircle,
  Eye,
  FileSpreadsheet
} from "lucide-react";
import { CleanedBMKGDay, PreprocessingSummary } from "../utils/preprocessing";
import { MONTHS } from "../data/datasets";

interface PreprocessingViewProps {
  rawBMKG: any[];
  cleanedDays: CleanedBMKGDay[];
  rawBPS: Record<string, number[]>;
  summary: PreprocessingSummary;
  rawStats: Record<string, number>;
  cleanStats: Record<string, number>;
}

export const PreprocessingView: React.FC<PreprocessingViewProps> = ({
  rawBMKG,
  cleanedDays,
  rawBPS,
  summary,
  rawStats,
  cleanStats
}) => {
  const [bmkgType, setBmkgType] = useState<"raw" | "cleaned">("raw");

  // Format dataset columns count
  const rawBMKGCols = 7; // tanggal, tmin, tmax, tavg, humidity, rainfall, sunshine
  const bpsTotalRows = Object.keys(rawBPS).length;
  const bpsTotalCols = 13; // Kabupaten + 12 bulan

  // Pick some interesting rows for raw preview (especially with dirty items)
  const rawPreviewRows = rawBMKG.filter((r, idx) => {
    // Show some dirty ones explicitly plus some standard rows
    const isDirty = r.curah_hujan === 8888 || r.curah_hujan === 9999 || r.suhu_avg === null || r.kelembapan_avg === 9999 || r.tanggal.includes("/") || r.tanggal.includes("-2025");
    return isDirty || idx === 10 || idx === 150 || idx === 300;
  }).slice(0, 8);

  // Match the exact date from cleaned list to display head-to-head comparison
  const cleanedPreviewRows = rawPreviewRows.map((raw) => {
    // Turn dates like "12-05-2025" or "2025/03/12" into standardized
    let stdDate = "";
    if (raw.tanggal.includes("/")) {
      const parts = raw.tanggal.split("/");
      stdDate = `${parts[0]}-${parts[1].padStart(2, "0")}-${parts[2].padStart(2, "0")}`;
    } else if (raw.tanggal.endsWith("-2025")) {
      const parts = raw.tanggal.split("-");
      stdDate = `2025-${parts[1].padStart(2, "0")}-${parts[0].padStart(2, "0")}`;
    } else {
      stdDate = raw.tanggal;
    }
    
    return cleanedDays.find((c) => c.tanggal === stdDate) || cleanedDays[0];
  }).filter(Boolean);

  return (
    <div id="preprocessing-view" className="space-y-6">
      
      {/* Visual Pipeline Flowchart */}
      <div id="pipeline-card" className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm">
        <h3 className="font-sans font-bold text-[#1a3c34] text-lg flex items-center gap-2">
          <Settings className="w-5 h-5 text-[#2d6a4f]" />
          Alur Rekayasa & Validasi Data (Pipeline)
        </h3>
        <p className="text-xs text-[#6b7c76] mt-1">
          Proses pemrosesan data curah hujan harian BMKG Bogor s.d penyamaan resolusi spasial-temporal data BPS
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 mt-6 relative">
          {/* Step 1 */}
          <div className="bg-[#f0f7f4] rounded-2xl p-4 border border-[#e2e8e0] flex flex-col justify-between relative group">
            <div>
              <div className="w-8 h-8 rounded-full bg-[#2d6a4f] text-white font-mono text-xs font-bold flex items-center justify-center">1</div>
              <h4 className="font-sans font-bold text-[#1a3c34] text-sm mt-3">Ingest Raw Data</h4>
              <p className="text-xs text-[#6b7c76] mt-1 leading-relaxed">
                Ingest data cuaca BMKG Stasiun Bogor (harian, 365 baris) & data panen padi BPS Jabar (27 wilayah × 12 bulan).
              </p>
            </div>
            <div className="hidden lg:block absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2 z-10 text-emerald-400">
              <ArrowRight className="w-5 h-5" />
            </div>
          </div>

          {/* Step 2 */}
          <div className="bg-[#f0f7f4] rounded-2xl p-4 border border-[#e2e8e0] flex flex-col justify-between relative">
            <div>
              <div className="w-8 h-8 rounded-full bg-[#2d6a4f] text-white font-mono text-xs font-bold flex items-center justify-center font-semibold">2</div>
              <h4 className="font-sans font-bold text-[#1a3c34] text-sm mt-3">Data Cleaning</h4>
              <p className="text-xs text-[#6b7c76] mt-1 leading-relaxed">
                Konversi kode BMKG 8888 & 9999 menjadi <span className="font-mono text-[#c2843e] bg-[#fff8f0] px-1 py-0.5 rounded">NaN</span>. Deduplikasi data tanggal, standardisasi ke format <code className="text-[#2d6a4f]">YYYY-MM-DD</code>.
              </p>
            </div>
            <div className="hidden lg:block absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2 z-10 text-emerald-400">
              <ArrowRight className="w-5 h-5" />
            </div>
          </div>

          {/* Step 3 */}
          <div className="bg-[#f0f7f4] rounded-2xl p-4 border border-[#e2e8e0] flex flex-col justify-between relative">
            <div>
              <div className="w-8 h-8 rounded-full bg-[#2d6a4f] text-white font-mono text-xs font-bold flex items-center justify-center font-semibold">3</div>
              <h4 className="font-sans font-bold text-[#1a3c34] text-sm mt-3">Imputasi Interpolasi</h4>
              <p className="text-xs text-[#6b7c76] mt-1 leading-relaxed">
                Mengisi missing value (NaN) menggunakan linear interpolation agar kesinambungan data cuaca dan deret waktu tetap terjaga.
              </p>
            </div>
            <div className="hidden lg:block absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2 z-10 text-emerald-400">
              <ArrowRight className="w-5 h-5" />
            </div>
          </div>

          {/* Step 4 */}
          <div className="bg-[#f0f7f4] rounded-2xl p-4 border border-[#e2e8e0] flex flex-col justify-between relative">
            <div>
              <div className="w-8 h-8 rounded-full bg-[#2d6a4f] text-white font-mono text-xs font-bold flex items-center justify-center font-semibold">4</div>
              <h4 className="font-sans font-bold text-[#1a3c34] text-sm mt-3">Temporal Aggregation</h4>
              <p className="text-xs text-[#6b7c76] mt-1 leading-relaxed">
                Mengubah harian menjadi bulanan. Model: Curah hujan dijumlahkan (<span className="italic font-medium">total sum</span>), sedangkan Suhu/Kelembapan menggunakan <span className="italic font-medium">average</span> bulanan.
              </p>
            </div>
            <div className="hidden lg:block absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2 z-10 text-emerald-400">
              <ArrowRight className="w-5 h-5" />
            </div>
          </div>

          {/* Step 5 */}
          <div className="bg-[#1a4d4d] text-white rounded-2xl p-4 border border-[#256060] flex flex-col justify-between">
            <div>
              <div className="w-8 h-8 rounded-full bg-[#a8dadc] text-[#1a3c34] font-mono text-xs font-bold flex items-center justify-center">5</div>
              <h4 className="font-sans font-bold text-[#a8dadc] text-sm mt-3">Integration & Analytics</h4>
              <p className="text-xs text-[#e8f3f1]/80 mt-1 leading-relaxed">
                Menyamakan data BMKG bulanan dengan data luas panen bulanan di level kabupaten/kota untuk visualisasi lag korelasi & analisis variabilitas.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Veracity Summary Cards (Comparison of state before and after) */}
      <div id="veracity-stats-cards" className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Preprocessing Summary Logs */}
        <div className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h4 className="font-sans font-bold text-[#1a3c34] text-base flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-[#e5383b]" />
              Rekap Eksekusi Cleaning (Veracity)
            </h4>
            <p className="text-xs text-[#6b7c76] mt-0.5">Penanganan anomali data harian BMKG Bogor 2025</p>
          </div>

          <div className="space-y-3 mt-4">
            <div className="flex justify-between items-center py-2 border-b border-slate-100">
              <span className="text-xs text-[#6b7c76]">Duplikasi Tanggal Terhapus</span>
              <span className="bg-[#fff5f5] text-[#e5383b] font-mono text-xs font-semibold px-2 py-0.5 rounded-full">
                {summary.duplicates_removed} Baris
              </span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-slate-100">
              <span className="text-xs text-[#6b7c76]">Nilai Invalid Terdeteksi (8888 & 9999)</span>
              <span className="bg-[#fff8f0] text-[#c2843e] font-mono text-xs font-semibold px-2 py-0.5 rounded-full">
                {summary.invalid_values_treated} Sel
              </span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-slate-100">
              <span className="text-xs text-[#6b7c76]">Imputasi Nilai Kosong (Linear Interpolation)</span>
              <span className="bg-[#f0f7f4] text-[#2d6a4f] font-mono text-xs font-semibold px-2 py-0.5 rounded-full">
                {summary.nulls_imputed} Sel
              </span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-xs text-[#6b7c76] font-medium">Status Akhir Dataset</span>
              <span className="bg-[#e7f5ef] text-[#2d6a4f] font-mono text-xs font-bold flex items-center gap-1 px-2.5 py-0.5 rounded-full">
                <CheckCircle className="w-3.5 h-3.5" /> CLEAN
              </span>
            </div>
          </div>
        </div>

        {/* Dataset Dimensions & Metrics Table */}
        <div className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm">
          <h4 className="font-sans font-bold text-[#1a3c34] text-base mb-4 flex items-center gap-2">
            <Database className="w-5 h-5 text-[#2d6a4f]" />
            Dimensi & Integritas Dataset Berkas
          </h4>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-[#6b7c76] font-medium">
                  <th className="py-2">Sumber Dataset</th>
                  <th className="py-2">Resolusi</th>
                  <th className="py-2">Ukuran (Baris x Kolom)</th>
                  <th className="py-2 text-right">Anomali Terbersihkan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-[#6b7c76]">
                <tr>
                  <td className="py-3 font-medium text-[#1a3c34]">BMKG Klimatologi</td>
                  <td className="py-3 font-mono">Harian (H)</td>
                  <td className="py-3 font-mono">{rawStats.total_records} × {rawBMKGCols}</td>
                  <td className="py-3 text-right font-semibold text-[#e5383b]">
                    {summary.duplicates_removed + summary.invalid_values_treated + summary.nulls_imputed} item
                  </td>
                </tr>
                <tr>
                  <td className="py-3 font-medium text-[#1a3c34]">BPS Luas Panen</td>
                  <td className="py-3 font-mono">Bulanan (M)</td>
                  <td className="py-3 font-mono">{bpsTotalRows} × {bpsTotalCols}</td>
                  <td className="py-3 text-right text-[#2d6a4f] font-semibold font-mono">0 (Groomed)</td>
                </tr>
                <tr className="bg-slate-50/50">
                  <td className="py-3 font-bold text-[#1a4d4d]">Integrated Set</td>
                  <td className="py-3 font-mono font-semibold text-[#1a4d4d]">Bulanan (M)</td>
                  <td className="py-3 font-mono font-semibold text-[#1a4d4d]">12 × 28</td>
                  <td className="py-3 text-right text-[#2d6a4f] font-bold font-mono">SINKRONISASI OK</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </div>

      {/* Comparative Data Grid (Raw vs Clean Head to Head preview) */}
      <div id="data-preview-panels" className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h4 className="font-sans font-bold text-[#1a3c34] text-base flex items-center gap-2">
              <Eye className="w-5 h-5 text-[#2d6a4f]" />
              Preview Head-to-Head Pembersihan BMKG
            </h4>
            <p className="text-xs text-[#6b7c76] mt-0.5">Membandingkan baris berkas anomali sebelum dan sesudah diproses pipeline</p>
          </div>
          
          <div className="flex bg-slate-100 p-1 rounded-xl">
            <button 
              onClick={() => setBmkgType("raw")}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition ${
                bmkgType === "raw" ? "bg-white text-[#1a3c34] shadow-sm" : "text-slate-450 hover:text-slate-700"
              }`}
            >
              Raw BMKG (Miring)
            </button>
            <button 
              onClick={() => setBmkgType("cleaned")}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition ${
                bmkgType === "cleaned" ? "bg-white text-[#2d6a4f] shadow-sm" : "text-slate-450 hover:text-slate-700"
              }`}
            >
              Standardized & Imputed
            </button>
          </div>
        </div>

        {/* BMKG Preview Table */}
        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold uppercase font-mono tracking-wider text-[10px] border-b border-slate-200">
                <th className="p-3">Tanggal</th>
                <th className="p-3">Suhu Min (°C)</th>
                <th className="p-3">Suhu Max (°C)</th>
                <th className="p-3">Suhu Rata-rata (°C)</th>
                <th className="p-3">Kelembapan (%)</th>
                <th className="p-3">Curah Hujan (mm)</th>
                <th className="p-3">Penyinaran (Jam)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-150 font-mono text-slate-700">
              {bmkgType === "raw" ? (
                rawPreviewRows.map((r, idx) => (
                  <tr key={idx} className="hover:bg-amber-50/10 transition-colors">
                    <td className="p-3 text-emerald-950 font-medium">{r.tanggal}</td>
                    <td className="p-3">{r.suhu_min ?? <span className="text-slate-400 font-serif">null</span>}</td>
                    <td className="p-3">{r.suhu_max ?? <span className="text-slate-400 font-serif">null</span>}</td>
                    <td className="p-3">{r.suhu_avg === null ? <span className="text-rose-500 font-sans italic bg-rose-50 px-1 py-0.5 rounded">null (Missing)</span> : r.suhu_avg}</td>
                    <td className="p-3">
                      {r.kelembapan_avg === 9999 ? (
                        <span className="text-amber-700 font-sans italic bg-amber-50 px-1 py-0.5 rounded">9999 (Invalid)</span>
                      ) : r.kelembapan_avg}
                    </td>
                    <td className="p-3">
                      {r.curah_hujan === 8888 || r.curah_hujan === 9999 ? (
                        <span className="text-red-600 font-sans italic bg-red-50 px-1 py-0.5 rounded font-medium">{r.curah_hujan} (Invalid)</span>
                      ) : r.curah_hujan}
                    </td>
                    <td className="p-3">{r.penyinaran_matahari ?? <span className="text-slate-455 font-serif">null</span>}</td>
                  </tr>
                ))
              ) : (
                cleanedPreviewRows.map((r, idx) => (
                  <tr key={idx} className="hover:bg-emerald-50/10 transition-colors bg-emerald-50/5">
                    <td className="p-3 text-[#2d6a4f] font-bold">{r.tanggal}</td>
                    <td className="p-3 font-medium">{r.suhu_min}</td>
                    <td className="p-3 font-medium">{r.suhu_max}</td>
                    <td className="p-3 text-[#2d6a4f] font-semibold">{r.suhu_avg}</td>
                    <td className="p-3">{r.kelembapan_avg}%</td>
                    <td className="p-3 text-[#2d6a4f] font-bold">{r.curah_hujan}</td>
                    <td className="p-3">{r.penyinaran_matahari}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* BPS Dataset Matrix overview */}
      <div id="bps-dataset-overview" className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm">
        <h4 className="font-sans font-bold text-[#1a3c34] text-base mb-2 flex items-center gap-2">
          <FileSpreadsheet className="w-5 h-5 text-[#2d6a4f]" />
          Preview Berkas Luas Panen Padi (BPS Jabar 2025)
        </h4>
        <p className="text-xs text-[#6b7c76] mb-4 font-normal">
          Unit pengamatan bulanan (dalam Hektar - Ha) untuk 27 kabupaten dan kota di Provinsi Jawa Barat.
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs select-none">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="p-2.5 font-sans font-semibold text-slate-600">Kabupaten / Kota</th>
                {MONTHS.map((m) => (
                  <th key={m} className="p-2.5 font-sans font-semibold text-slate-500 text-center">{m.slice(0, 3)}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-slate-700 text-[11px]">
              {(Object.entries(rawBPS) as [string, number[]][]).slice(0, 7).map(([regency, vals]) => (
                <tr key={regency} className="hover:bg-emerald-50/10 transition-colors">
                  <td className="p-2.5 font-sans font-medium text-slate-800">{regency}</td>
                  {vals.map((v, i) => (
                    <td key={i} className="p-2.5 text-center text-slate-650">{v.toLocaleString("id-ID")}</td>
                  ))}
                </tr>
              ))}
              <tr className="bg-slate-50 text-[10px] text-slate-400 font-sans italic">
                <td className="p-2.5" colSpan={13}>+ 20 kabupaten/kota lainnya tercakup dalam memori analisis...</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
