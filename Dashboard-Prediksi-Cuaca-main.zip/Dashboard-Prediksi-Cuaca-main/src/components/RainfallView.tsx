/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  CloudRain, 
  Search, 
  HelpCircle,
  TrendingUp,
  Award,
  CalendarDays,
  Info
} from "lucide-react";
import { 
  ComposedChart, 
  Bar, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ReferenceArea, 
  ResponsiveContainer 
} from "recharts";
import { MonthlyBMKG } from "../utils/preprocessing";

interface RainfallViewProps {
  monthlyRainfall: MonthlyBMKG[];
}

export const RainfallView: React.FC<RainfallViewProps> = ({ monthlyRainfall }) => {
  
  // Dynamic statistics & lists
  const optimalMonths: string[] = [];
  const excessiveMonths: string[] = [];
  const lowMonths: string[] = [];
  const criticalMonths: string[] = [];
  
  let peakRainMonth = monthlyRainfall[0];
  let dryRainMonth = monthlyRainfall[0];

  monthlyRainfall.forEach((m) => {
    const rain = m.total_curah_hujan;
    if (rain < 50) {
      criticalMonths.push(m.bulan_nama);
    } else if (rain >= 50 && rain < 100) {
      lowMonths.push(m.bulan_nama);
    } else if (rain >= 100 && rain <= 200) {
      optimalMonths.push(m.bulan_nama);
    } else {
      excessiveMonths.push(m.bulan_nama);
    }

    if (rain > peakRainMonth.total_curah_hujan) peakRainMonth = m;
    if (rain < dryRainMonth.total_curah_hujan) dryRainMonth = m;
  });

  // Prepare chart data format
  const chartData = monthlyRainfall.map((m) => ({
    name: m.bulan_nama.slice(0, 3),
    fullName: m.bulan_nama,
    Rainfall: m.total_curah_hujan,
    TempMin: m.avg_suhu_min,
    TempMax: m.avg_suhu_max,
    TempAvg: m.avg_suhu_avg,
    Kelembapan: m.avg_kelembapan
  }));

  // Tooltip content formatter
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      const r = data.Rainfall;
      let status = "";
      let statusClass = "";
      
      if (r < 50) {
        status = "Sangat Kritis (Kering) (< 50 mm)";
        statusClass = "text-[#e5383b] font-bold";
      } else if (r >= 50 && r < 100) {
        status = "Rendah (50 s.d 100 mm)";
        statusClass = "text-[#c2843e] font-medium";
      } else if (r >= 100 && r <= 200) {
        status = "Optimal (100 s.d 200 mm)";
        statusClass = "text-[#2d6a4f] font-bold";
      } else {
        status = "Berlebih (> 200 mm)";
        statusClass = "text-[#4361ee] font-bold";
      }

      return (
        <div className="bg-white/95 border border-[#e2e8e0] rounded-xl p-4 shadow-lg text-xs leading-relaxed max-w-xs">
          <p className="font-semibold text-[#1a3c34] text-sm mb-1.5">{data.fullName} 2025</p>
          <div className="space-y-1 text-[#6b7c76]">
            <p className="flex justify-between gap-4">
              <span>Curah Hujan:</span>
              <strong className="text-[#1a3c34]">{r.toLocaleString("id-ID")} mm</strong>
            </p>
            <p className="flex justify-between gap-4 border-b border-slate-100 pb-1.5 mb-1.5">
              <span>Kesesuaian Tanam:</span>
              <span className={statusClass}>{status}</span>
            </p>
            <p className="flex justify-between gap-4">
              <span>Suhu Rerata:</span>
              <span>{data.TempAvg} °C</span>
            </p>
            <p className="flex justify-between gap-4">
              <span>Kelembapan Udara:</span>
              <span>{data.Kelembapan}%</span>
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div id="rainfall-view" className="space-y-6">

      {/* Main Bar Chart Panel */}
      <div id="rainfall-trend-charts" className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* Responsive Area bands with Curah Hujan Recharts Map */}
        <div className="xl:col-span-2 bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <h3 className="font-sans font-bold text-[#1a3c34] text-lg flex items-center gap-2">
                <CloudRain className="w-5 h-5 text-[#2d6a4f]" />
                Tren Curah Hujan Bulanan & Pita Kesesuaian Air Padi
              </h3>
              <span className="text-[10px] font-mono font-bold text-[#2d6a4f] bg-[#f0f7f4] border border-[#e2e8e0] px-2 py-0.5 rounded-full">
                Bogor Station (Proxy 2025)
              </span>
            </div>
            <p className="text-xs text-[#6b7c76] mt-1">
              Grafik gabungan curah hujan bulanan yang disandingkan langsung dengan batas klasifikasi kecukupan air tanaman padi sawah.
            </p>
          </div>

          <div className="h-96 w-full mt-6 text-xs select-none">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData} margin={{ top: 20, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" tickLine={false} />
                <YAxis stroke="#94a3b8" tickLine={false} domain={[0, 480]} />
                <Tooltip content={<CustomTooltip />} />
                <Legend iconType="circle" />
                
                {/* Reference Bands for rice water suitability zones */}
                {/* 1. Sangat Kritis (< 50 mm) */}
                {/* @ts-expect-error - Recharts ReferenceArea compatibility */}
                <ReferenceArea y1={0} y2={50} fill="#fca5a5" fillOpacity={0.12} />
                {/* 2. Rendah (50 - 100 mm) */}
                {/* @ts-expect-error - Recharts ReferenceArea compatibility */}
                <ReferenceArea y1={50} y2={100} fill="#fef08a" fillOpacity={0.15} />
                {/* 3. Optimal (100 - 200 mm) */}
                {/* @ts-expect-error - Recharts ReferenceArea compatibility */}
                <ReferenceArea y1={100} y2={200} fill="#86efac" fillOpacity={0.18} />
                {/* 4. Berlebih (> 200 mm) */}
                {/* @ts-expect-error - Recharts ReferenceArea compatibility */}
                <ReferenceArea y1={200} y2={480} fill="#93c5fd" fillOpacity={0.10} />
                
                {/* Curah Hujan (Sum Columns) */}
                <Bar 
                  name="Curah Hujan (RR mm)" 
                  dataKey="Rainfall" 
                  fill="#2d6a4f" 
                  radius={[6, 6, 0, 0]} 
                  barSize={24} 
                />
                
                {/* Temperature overlay */}
                <Line 
                  name="Suhu Rerata (°C)" 
                  dataKey="TempAvg" 
                  stroke="#c2843e" 
                  strokeWidth={2}
                  dot={{ r: 4, stroke: "#ffffff", strokeWidth: 2 }}
                  activeDot={{ r: 6 }} 
                  type="monotone"
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 mt-4 border-t border-slate-100 pt-3 text-[11px] text-slate-500 font-medium">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-2 rounded bg-red-100 border border-red-200"></span>
              <span>Sangat Kritis (&lt; 50 mm)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-2 rounded bg-yellow-100 border border-yellow-200"></span>
              <span>Rendah (50 s.d 100 mm)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-2 rounded bg-emerald-100 border border-emerald-200"></span>
              <span>Optimal (100 s.d 200 mm)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-2 rounded bg-blue-100 border border-blue-200"></span>
              <span>Berlebih (&gt; 200 mm)</span>
            </div>
          </div>
        </div>

        {/* Categories explanation box */}
        <div className="bg-white rounded-3xl border border-[#e2e8e0] p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h4 className="font-sans font-bold text-[#1a3c34] text-base mb-4 flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-[#2d6a4f]" />
              Acuan Kebutuhan Air Padi d/h BMKG
            </h4>
            
            <div className="space-y-4">
              <div className="p-3.5 bg-[#fff5f5] rounded-xl border border-[#f8d7da]">
                <div className="flex justify-between font-semibold text-[#e5383b] text-xs">
                  <span>&lt; 50 mm</span>
                  <span>Sangat Kritis/Kering</span>
                </div>
                <p className="text-[11px] text-[#e5383b]/90 mt-1 leading-relaxed">
                  Kekurangan pasokan air. Dapat memicu kegagalan pertumbuhan tanaman muda (stadia vegetatif), kekeringan, hingga kekosongan bulir (fuso).
                </p>
              </div>

              <div className="p-3.5 bg-[#fff8f0] rounded-xl border border-[#fbe9d0]">
                <div className="flex justify-between font-semibold text-[#c2843e] text-xs">
                  <span>50–100 mm</span>
                  <span>Rendah</span>
                </div>
                <p className="text-[11px] text-[#c2843e]/95 mt-1 leading-relaxed">
                  Cukup untuk padi gogo (lahan kering), namun masih kurang bagi padi sawah murni kecuali ditunjang suplai irigasi teknis yang prima.
                </p>
              </div>

              <div className="p-3.5 bg-[#f0f7f4] rounded-xl border border-[#e2e8e0]">
                <div className="flex justify-between font-semibold text-[#2d6a4f] text-xs">
                  <span>100–200 mm</span>
                  <span>Optimal</span>
                </div>
                <p className="text-[11px] text-[#2d6a4f]/95 mt-1 leading-relaxed">
                  Zona ideal mendukung pertumbuhan semua stadia padi sawah tanpa beban sistem drainase berlebih. Sangat baik untuk memulai pengolahan sawah.
                </p>
              </div>

              <div className="p-3.5 bg-[#f0f4ff] rounded-xl border-[#d6e4ff]">
                <div className="flex justify-between font-semibold text-[#4361ee] text-xs">
                  <span>&gt; 200 mm</span>
                  <span>Berlebih</span>
                </div>
                <p className="text-[11px] text-[#4361ee]/95 mt-1 leading-relaxed">
                  Curah air tinggi. Perlu diantisipasi karena memicu ancaman luapan banjir di bantaran hilir, pembusukan akar muda, dan melumpuhkan aktivitas panen.
                </p>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Automated insights section */}
      <div id="automated-insights-rain" className="bg-[#1a4d4d] text-white rounded-3xl p-6 shadow-md border border-[#256060]">
        <h4 className="font-sans font-bold text-[#a8dadc] text-base mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-[#a8dadc]" />
          Insight Agroklimatologi Otomatis (Tahun Analisis 2025)
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 leading-relaxed text-xs">
          
          {/* Section 1 */}
          <div className="space-y-3.5 text-[#e8f3f1]/90">
            <div className="flex items-start gap-2.5">
              <CalendarDays className="w-4 h-4 text-[#a8dadc] shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block">Siklus Bulan Optimal</strong>
                <span>
                  {optimalMonths.length > 0 ? (
                    <>Berdasarkan curah hujan rata-rata, bulan <strong>{optimalMonths.join(", ")}</strong> masuk dalam kriteria <strong>Optimal (100–200 mm)</strong> untuk penyiapan lahan sawah basah.</>
                  ) : (
                    "Tidak terdeteksi bulan dengan curah hujan kriteria optimal murni pada tahun ini."
                  )}
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <CloudRain className="w-4 h-4 text-cyan-350 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block">Siklus Curah Hujan Berlebih</strong>
                <span>
                  Bulan <strong>{excessiveMonths.join(", ")}</strong> mencatatkan kelebihan air (<strong>&gt; 200 mm</strong>). Diperlukan aktivasi drainase yang waspada untuk menghindari genangan di areal pembibitan padi gadu/rendengan.
                </span>
              </div>
            </div>
          </div>

          {/* Section 2 */}
          <div className="space-y-3.5 text-[#e8f3f1]/90">
            <div className="flex items-start gap-2.5">
              <Award className="w-4 h-4 text-[#a8dadc] shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block">Ekstrim Tertinggi (Puncak Basah)</strong>
                <span>
                  Puncak curah hujan tertinggi terjadi di bulan <strong>{peakRainMonth.bulan_nama}</strong> yaitu mencapai <strong>{peakRainMonth.total_curah_hujan.toLocaleString("id-ID")} mm</strong>. Masa basah ini merefleksikan tingginya curah jenuh di hulu Bogor.
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <Info className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block">Ekstrim Terendah (Titik Terkering)</strong>
                <span>
                  Titik kering terdalam di tahun 2025 tercatat pada bulan <strong>{dryRainMonth.bulan_nama}</strong> dengan curah hujan sebesar <strong>{dryRainMonth.total_curah_hujan.toLocaleString("id-ID")} mm</strong>, masuk dalam rentang <strong>{dryRainMonth.total_curah_hujan < 50 ? "Sangat Kritis" : "Rendah"}</strong>. Periode ini menggambarkan puncak kemarau regional Jawa Barat.
                </span>
              </div>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
};
