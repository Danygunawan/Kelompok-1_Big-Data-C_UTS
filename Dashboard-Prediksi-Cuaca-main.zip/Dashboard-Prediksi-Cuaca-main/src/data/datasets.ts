/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// List of all 27 regencies and cities in West Java
export const REGENCY_LIST = [
  "Kab. Bogor",
  "Kab. Sukabumi",
  "Kab. Cianjur",
  "Kab. Bandung",
  "Kab. Garut",
  "Kab. Tasikmalaya",
  "Kab. Ciamis",
  "Kab. Kuningan",
  "Kab. Cirebon",
  "Kab. Majalengka",
  "Kab. Sumedang",
  "Kab. Indramayu", // Lumbung padi #1
  "Kab. Subang",    // Lumbung padi #2
  "Kab. Purwakarta",
  "Kab. Karawang",   // Lumbung padi #3
  "Kab. Bekasi",
  "Kab. Bandung Barat",
  "Kab. Pangandaran",
  "Kota Bogor",
  "Kota Sukabumi",
  "Kota Bandung",
  "Kota Cirebon",
  "Kota Bekasi",
  "Kota Depok",
  "Kota Cimahi",
  "Kota Tasikmalaya",
  "Kota Banjar"
];

// Month names list
export const MONTHS = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember"
];

// Helper to generate BMKG daily data for Bogor, Jawa Barat in 2025
// Includes seasonal trends (rainy season: Jan-Apr, Oct-Dec; drier season: May-Sep)
// Includes dirty values (8888, 9999, NaNs, duplicate dates, out-of-order) to trace the cleaning workflow
export function generateRawBMKGData(): any[] {
  const data: any[] = [];
  const start = new Date("2025-01-01");
  const end = new Date("2025-12-31");
  
  let current = new Date(start);
  
  // Seedable simple random values
  let seed = 42;
  function random(): number {
    const x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
  }

  while (current <= end) {
    const dateStr = current.toISOString().split("T")[0];
    const month = current.getMonth(); // 0-11
    
    // Seasonal patterns (Bogor weather is famously humid and wet)
    // Rainfall pattern (wet: Jan-Apr, Oct-Dec; drier: Jun-Aug)
    let baseRainProb = 0.65; // High base probability in Bogor
    let baseIntensity = 15; // Mean rainfall (mm)
    
    if (month >= 4 && month <= 7) { // May to August (Drier)
      baseRainProb = 0.35;
      baseIntensity = 8;
    } else if (month === 10 || month === 11 || month === 0) { // Nov, Dec, Jan (Very wet)
      baseRainProb = 0.78;
      baseIntensity = 22;
    }
    
    let rainfall = 0;
    if (random() < baseRainProb) {
      rainfall = Math.round(random() * baseIntensity * 1.8 * 10) / 10;
    }
    
    // Suhu (Temp)
    const t_avg = Math.round((24.5 + random() * 2.5 + (month >= 5 && month <= 7 ? 0.8 : 0)) * 10) / 10;
    const t_min = Math.round((t_avg - (2.5 + random() * 1.5)) * 10) / 10;
    const t_max = Math.round((t_avg + (4.0 + random() * 2.5)) * 10) / 10;
    
    // Humidity
    const humidity = Math.round(82 + (rainfall > 0 ? 5 : -4) - (month >= 5 && month <= 8 ? 3 : 0) + random() * 4);
    
    // Sunshine duration (jam)
    const sunshine = Math.max(0, Math.min(12, Math.round((rainfall > 0 ? 2 + random() * 3 : 5 + random() * 5) * 10) / 10));

    // Construct record
    const record: any = {
      tanggal: dateStr,
      suhu_min: t_min,
      suhu_max: t_max,
      suhu_avg: t_avg,
      kelembapan_avg: humidity,
      curah_hujan: rainfall,
      penyinaran_matahari: sunshine
    };
    
    // Introduce DIRTY data intentionally to showcase VERACITY cleaning:
    // 1. Missing values (null)
    // 2. Erroneous markers 8888 (means "data not measured") or 9999 (means "missing indicator" in some BMKG raw logs)
    const r = random();
    if (r < 0.02) {
      // 2% have 8888 or 9999 in curah_hujan (normally represents trace / missing)
      record.curah_hujan = random() < 0.5 ? 8888 : 9999;
    } else if (r < 0.04) {
      // Nulls in temperature
      record.suhu_avg = null;
    } else if (r < 0.06) {
      record.kelembapan_avg = 9999;
    } else if (r < 0.07) {
      record.penyinaran_matahari = null;
    }
    
    data.push(record);
    
    // 3. Intentionally introduce duplicate record sometimes
    if (r > 0.985 && data.length > 5) {
      data.push({ ...record }); // Duplicate entry and sibling in array
    }

    current.setDate(current.getDate() + 1);
  }
  
  // Let us modify some date formats randomly to represent raw text reading differences
  // like "2025/03/12" or "12-05-2025" for a few rows
  for (let i = 0; i < data.length; i += 41) {
    if (data[i]) {
      const parts = data[i].tanggal.split("-");
      if (i % 2 === 0) {
        data[i].tanggal = `${parts[0]}/${parts[1]}/${parts[2]}`; // YYYY/MM/DD
      } else {
        data[i].tanggal = `${parts[2]}-${parts[1]}-${parts[0]}`; // DD-MM-YYYY
      }
    }
  }

  return data;
}

// Generates monthly rice harvest area (Luas Panen Padi in hectares) for Jabar 2025
// Realistically, West Java produces huge quantities, with Indramayu as the king (~150,000 to 220,000 ha annually)
// Karawang, Subang, and Cianjur are also major producers.
// Cities have very low harvest area (often near-zero).
// Distribution exhibits dual crop cycle peaks:
// Peak 1 (Maret-April-Mei) - Main harvest after rainy season planting
// Peak 2 (Juli-Agustus-September) - Gadu harvest
export function generateRawBPSData(): Record<string, number[]> {
  const harvestData: Record<string, number[]> = {};

  // Standard seasonal distribution factors for the 12 months (summing to approx 1.0)
  // High in Mar-Apr-May (peak), then Jul-Aug-Sep (secondary), very low in Dec-Jan
  const seasonalFactors = [
    0.03, // Jan (tanam Nov-Dec, barely any harvest)
    0.05, // Feb
    0.18, // Mar (Peak Harvest #1)
    0.24, // Apr (Peak Harvest #2)
    0.15, // Mei
    0.06, // Jun
    0.09, // Jul (Peak Harvest Gadu #1)
    0.12, // Ags (Peak Harvest Gadu #2)
    0.05, // Sep
    0.01, // Okt (Worst dry, preparations)
    0.01, // Nov
    0.01  // Des
  ];

  REGENCY_LIST.forEach((regency) => {
    // Determine annual total harvest area (Hectares) based on real relative proportions
    let annualTotal = 15000; // default medium-sized
    
    if (regency === "Kab. Indramayu") {
      annualTotal = 215000; // The premier rice basket
    } else if (regency === "Kab. Karawang") {
      annualTotal = 185000; // Large basket
    } else if (regency === "Kab. Subang") {
      annualTotal = 155000; // Large basket
    } else if (regency === "Kab. Cianjur") {
      annualTotal = 85000;  // High producer
    } else if (regency === "Kab. Sukabumi") {
      annualTotal = 75000;
    } else if (regency === "Kab. Garut") {
      annualTotal = 62000;
    } else if (regency === "Kab. Tasikmalaya") {
      annualTotal = 58000;
    } else if (regency === "Kab. Cirebon") {
      annualTotal = 48000;
    } else if (regency === "Kab. Bandung") {
      annualTotal = 42000;
    } else if (regency === "Kab. Majalengka") {
      annualTotal = 45000;
    } else if (regency === "Kab. Sumedang") {
      annualTotal = 32000;
    } else if (regency === "Kab. Ciamis") {
      annualTotal = 28000;
    } else if (regency === "Kab. Kuningan") {
      annualTotal = 24000;
    } else if (regency === "Kab. Bekasi") {
      annualTotal = 22000;
    } else if (regency === "Kab. Bandung Barat") {
      annualTotal = 18000;
    } else if (regency === "Kab. Pangandaran") {
      annualTotal = 16000;
    } else if (regency === "Kab. Purwakarta") {
      annualTotal = 14000;
    } else if (regency.startsWith("Kota")) {
      // Cities have compact boundaries, minimal farming
      if (regency === "Kota Tasikmalaya") annualTotal = 4500;
      else if (regency === "Kota Banjar") annualTotal = 3200;
      else annualTotal = 50 + Math.floor(Math.random() * 300); // minimal
    }
    
    // Generate the 12 month values based on annualTotal and factors + local slight variance
    const monthlyValues = seasonalFactors.map((factor, idx) => {
      let varianceSeed = Math.sin(idx + regency.length) * 0.15; // slightly fluctuates by regency
      let adjustedFactor = Math.max(0.005, factor + varianceSeed);
      
      // Scale it
      let val = Math.round(annualTotal * adjustedFactor);
      
      // Enforce realistic bounds
      return Math.max(10, val);
    });

    harvestData[regency] = monthlyValues;
  });

  return harvestData;
}
